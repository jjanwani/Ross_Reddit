import { UserProfileHeader } from "@/components/UserProfileHeader";
import { StatsCard } from "@/components/StatsCard";
import { Users, MessageSquare, Calendar, BookOpen } from "lucide-react";
import avatar4 from "@assets/generated_images/Student_profile_avatar_4_bb25f0b0.png";

export default function Profile() {
  return (
    <div className="flex-1 overflow-auto">
      <UserProfileHeader
        name="Jordan Martinez"
        avatar={avatar4}
        email="jmartinez@umich.edu"
        year="Junior"
        major="Business Administration"
        interests={["Consulting", "Strategy", "Case Interviews", "Entrepreneurship"]}
        bio="Passionate about strategy consulting and helping underclassmen navigate recruiting. Currently interning at Bain & Company. Always happy to chat about case prep, networking, or anything Ross-related!"
        role="both"
      />

      <div className="max-w-4xl mx-auto p-6 space-y-6">
        <div>
          <h2 className="text-2xl font-semibold mb-4">Your Activity</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatsCard
              title="Active Matches"
              value={12}
              icon={Users}
              trend={{ value: "+3 this month", isPositive: true }}
            />
            <StatsCard
              title="Questions Answered"
              value={28}
              icon={MessageSquare}
              trend={{ value: "+8 this week", isPositive: true }}
            />
            <StatsCard
              title="Events Attended"
              value={6}
              icon={Calendar}
              trend={{ value: "2 upcoming", isPositive: true }}
            />
            <StatsCard title="Resources Saved" value={15} icon={BookOpen} />
          </div>
        </div>
      </div>
    </div>
  );
}
