import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { formatDistanceToNow } from "date-fns";
import { ArrowLeft, ThumbsUp, MessageSquare, Hash, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { ForumPost, ForumResponse, UserProfile } from "@shared/schema";

const CURRENT_USER_ID = "user1";

export default function ForumPostPage() {
  const [, params] = useRoute("/forum/:postId");
  const postId = params?.postId;
  const [responseContent, setResponseContent] = useState("");
  const [isAnonymousResponse, setIsAnonymousResponse] = useState(false);
  const { toast } = useToast();

  const { data: post, isLoading: postLoading } = useQuery<ForumPost>({
    queryKey: [`/api/forum/posts/${postId}`],
    enabled: !!postId,
  });

  const { data: responses = [], isLoading: responsesLoading } = useQuery<ForumResponse[]>({
    queryKey: [`/api/forum/posts/${postId}/responses`],
    enabled: !!postId,
  });

  const { data: allProfiles = [] } = useQuery<UserProfile[]>({
    queryKey: ["/api/profiles"],
  });

  const { data: currentUserProfile } = useQuery<UserProfile>({
    queryKey: [`/api/profiles/${CURRENT_USER_ID}`],
  });

  const upvoteMutation = useMutation({
    mutationFn: async (postId: string) => {
      return apiRequest("POST", `/api/forum/posts/${postId}/upvote`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/forum/posts/${postId}`] });
    },
  });

  const createResponseMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", `/api/forum/posts/${postId}/responses`, {
        postId: postId,
        authorId: CURRENT_USER_ID,
        content: responseContent,
        isAnonymous: isAnonymousResponse ? "true" : "false",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/forum/posts/${postId}/responses`] });
      setResponseContent("");
      setIsAnonymousResponse(false);
      toast({
        title: "Response posted!",
        description: "Your response has been added to the discussion.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to post response. Please try again.",
        variant: "destructive",
      });
    },
  });

  const getProfileById = (userId: string) => {
    return allProfiles.find((p) => p.userId === userId);
  };

  const getAuthorDisplay = (authorId: string, isAnonymous: string) => {
    if (isAnonymous === "true") {
      return { name: "Anonymous", initials: "A", program: "" };
    }
    const profile = getProfileById(authorId);
    if (!profile) {
      return { name: "Unknown User", initials: "U", program: "" };
    }
    return {
      name: profile.fullName,
      initials: profile.fullName
        .split(" ")
        .map((n) => n[0])
        .join(""),
      program: `${profile.program} '${profile.graduationYear}`,
    };
  };

  const handlePostResponse = () => {
    if (!responseContent.trim()) {
      toast({
        title: "Missing content",
        description: "Please write a response before posting.",
        variant: "destructive",
      });
      return;
    }
    createResponseMutation.mutate();
  };

  if (!postId) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Post not found</h2>
          <Link href="/forum">
            <Button variant="outline">Back to Forum</Button>
          </Link>
        </div>
      </div>
    );
  }

  if (postLoading) {
    return (
      <div className="flex-1 overflow-auto">
        <div className="max-w-4xl mx-auto p-6 space-y-6">
          <Card className="p-6 animate-pulse">
            <div className="h-8 bg-muted rounded w-3/4 mb-4"></div>
            <div className="h-4 bg-muted rounded w-full mb-2"></div>
            <div className="h-4 bg-muted rounded w-full mb-2"></div>
            <div className="h-4 bg-muted rounded w-2/3"></div>
          </Card>
        </div>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Post not found</h2>
          <Link href="/forum">
            <Button variant="outline">Back to Forum</Button>
          </Link>
        </div>
      </div>
    );
  }

  const author = getAuthorDisplay(post.authorId, post.isAnonymous);

  return (
    <div className="flex-1 overflow-auto">
      <div className="max-w-4xl mx-auto p-6 space-y-6">
        <Link href="/forum">
          <Button variant="ghost" size="sm" data-testid="button-back-to-forum">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Forum
          </Button>
        </Link>

        <Card className="p-6" data-testid="card-forum-post">
          <div className="flex gap-4">
            <Avatar className="h-12 w-12 shrink-0">
              <AvatarFallback>{author.initials}</AvatarFallback>
            </Avatar>

            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-2 mb-2">
                <div>
                  <p className="font-semibold text-lg">{author.name}</p>
                  {author.program && (
                    <p className="text-sm text-muted-foreground">{author.program}</p>
                  )}
                </div>
                <span className="text-sm text-muted-foreground shrink-0">
                  {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}
                </span>
              </div>

              <h1 className="text-2xl font-bold mb-4" data-testid="text-post-title">
                {post.title}
              </h1>

              <p className="text-foreground mb-4 whitespace-pre-wrap" data-testid="text-post-content">
                {post.content}
              </p>

              {post.hashtags.length > 0 && (
                <div className="flex flex-wrap gap-2 mb-4">
                  {post.hashtags.map((tag, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      <Hash className="h-3 w-3 mr-1" />
                      {tag}
                    </Badge>
                  ))}
                </div>
              )}

              <div className="flex items-center gap-4">
                <Button
                  variant="ghost"
                  size="sm"
                  className="gap-2"
                  onClick={() => upvoteMutation.mutate(post.id)}
                  data-testid="button-upvote"
                >
                  <ThumbsUp className="h-4 w-4" />
                  <span>{post.upvotes}</span>
                </Button>

                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <MessageSquare className="h-4 w-4" />
                  <span data-testid="text-response-count">
                    {responses.length} {responses.length === 1 ? "response" : "responses"}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="text-lg font-semibold mb-4">Your Response</h2>
          
          <div className="space-y-4">
            <Textarea
              placeholder="Share your thoughts, insights, or advice..."
              rows={4}
              value={responseContent}
              onChange={(e) => setResponseContent(e.target.value)}
              data-testid="textarea-response-content"
            />

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Switch
                  id="anonymous-response"
                  checked={isAnonymousResponse}
                  onCheckedChange={setIsAnonymousResponse}
                  data-testid="switch-anonymous-response"
                />
                <Label htmlFor="anonymous-response" className="text-sm cursor-pointer">
                  Post anonymously
                </Label>
              </div>

              <Button
                onClick={handlePostResponse}
                disabled={createResponseMutation.isPending || !responseContent.trim()}
                data-testid="button-post-response"
              >
                {createResponseMutation.isPending ? (
                  "Posting..."
                ) : (
                  <>
                    <Send className="h-4 w-4 mr-2" />
                    Post Response
                  </>
                )}
              </Button>
            </div>
          </div>
        </Card>

        <div className="space-y-4">
          <h2 className="text-xl font-bold">
            {responses.length} {responses.length === 1 ? "Response" : "Responses"}
          </h2>

          {responsesLoading ? (
            <div className="space-y-4">
              {[1, 2].map((i) => (
                <Card key={i} className="p-6 animate-pulse">
                  <div className="h-4 bg-muted rounded w-3/4 mb-4"></div>
                  <div className="h-3 bg-muted rounded w-full mb-2"></div>
                  <div className="h-3 bg-muted rounded w-2/3"></div>
                </Card>
              ))}
            </div>
          ) : responses.length === 0 ? (
            <Card className="p-8 text-center">
              <MessageSquare className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">
                No responses yet. Be the first to share your thoughts!
              </p>
            </Card>
          ) : (
            <div className="space-y-4">
              {responses.map((response) => {
                const responseAuthor = getAuthorDisplay(response.authorId, response.isAnonymous);

                return (
                  <Card key={response.id} className="p-6" data-testid={`card-response-${response.id}`}>
                    <div className="flex gap-4">
                      <Avatar className="h-10 w-10 shrink-0">
                        <AvatarFallback>{responseAuthor.initials}</AvatarFallback>
                      </Avatar>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2 mb-2">
                          <div>
                            <p className="font-semibold">{responseAuthor.name}</p>
                            {responseAuthor.program && (
                              <p className="text-sm text-muted-foreground">
                                {responseAuthor.program}
                              </p>
                            )}
                          </div>
                          <span className="text-sm text-muted-foreground shrink-0">
                            {formatDistanceToNow(new Date(response.createdAt), {
                              addSuffix: true,
                            })}
                          </span>
                        </div>

                        <p className="text-foreground whitespace-pre-wrap">
                          {response.content}
                        </p>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
