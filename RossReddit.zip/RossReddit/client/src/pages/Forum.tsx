import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { formatDistanceToNow } from "date-fns";
import { Plus, Search, ThumbsUp, MessageSquare, Hash } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { ForumPost, UserProfile } from "@shared/schema";

const CURRENT_USER_ID = "user1";

export default function Forum() {
  const [searchQuery, setSearchQuery] = useState("");
  const [isAskDialogOpen, setIsAskDialogOpen] = useState(false);
  const [newQuestion, setNewQuestion] = useState({
    title: "",
    content: "",
    hashtags: "",
    isAnonymous: false,
  });
  const { toast } = useToast();
  const [, params] = useRoute("/forum/:postId");

  const buildSearchURL = () => {
    if (searchQuery.trim()) {
      return `/api/forum/posts?search=${encodeURIComponent(searchQuery)}`;
    }
    return "/api/forum/posts";
  };

  const { data: posts = [], isLoading } = useQuery<ForumPost[]>({
    queryKey: [buildSearchURL()],
  });

  const { data: currentUserProfile } = useQuery<UserProfile>({
    queryKey: [`/api/profiles/${CURRENT_USER_ID}`],
  });

  const { data: allProfiles = [] } = useQuery<UserProfile[]>({
    queryKey: ["/api/profiles"],
  });

  const createPostMutation = useMutation({
    mutationFn: async (postData: typeof newQuestion) => {
      const hashtagsArray = postData.hashtags
        .split(",")
        .map((tag) => tag.trim())
        .filter((tag) => tag.length > 0);

      return apiRequest("POST", "/api/forum/posts", {
        authorId: CURRENT_USER_ID,
        title: postData.title,
        content: postData.content,
        hashtags: hashtagsArray,
        isAnonymous: postData.isAnonymous ? "true" : "false",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/forum/posts"] });
      setIsAskDialogOpen(false);
      setNewQuestion({ title: "", content: "", hashtags: "", isAnonymous: false });
      toast({
        title: "Question posted!",
        description: "Your question has been posted to the forum.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to post question. Please try again.",
        variant: "destructive",
      });
    },
  });

  const upvoteMutation = useMutation({
    mutationFn: async (postId: string) => {
      return apiRequest("POST", `/api/forum/posts/${postId}/upvote`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/forum/posts"] });
    },
  });

  const getProfileById = (userId: string) => {
    return allProfiles.find((p) => p.userId === userId);
  };

  const getAuthorDisplay = (post: ForumPost) => {
    if (post.isAnonymous === "true") {
      return { name: "Anonymous", initials: "A", program: "" };
    }
    const profile = getProfileById(post.authorId);
    if (!profile) {
      return { name: "Unknown User", initials: "U", program: "" };
    }
    return {
      name: profile.fullName,
      initials: profile.fullName
        .split(" ")
        .map((n) => n[0])
        .join(""),
      program: `${profile.program} '${profile.graduationYear}`,
    };
  };

  const handleAskQuestion = () => {
    if (!newQuestion.title.trim() || !newQuestion.content.trim()) {
      toast({
        title: "Missing information",
        description: "Please provide both a title and content for your question.",
        variant: "destructive",
      });
      return;
    }
    createPostMutation.mutate(newQuestion);
  };

  return (
    <div className="flex-1 overflow-auto">
      <div className="max-w-4xl mx-auto p-6 space-y-6">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div>
            <h1 className="text-4xl font-bold tracking-tight mb-2">Forum</h1>
            <p className="text-muted-foreground">
              Ask questions, share insights, and learn from the Ross community.
            </p>
          </div>
          
          <Dialog open={isAskDialogOpen} onOpenChange={setIsAskDialogOpen}>
            <DialogTrigger asChild>
              <Button data-testid="button-ask-question">
                <Plus className="h-4 w-4 mr-2" />
                Ask Question
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Ask a Question</DialogTitle>
                <DialogDescription>
                  Share your question with the Ross community. Add hashtags to make it easier to find.
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Question Title</Label>
                  <Input
                    id="title"
                    placeholder="What's your question?"
                    value={newQuestion.title}
                    onChange={(e) => setNewQuestion({ ...newQuestion, title: e.target.value })}
                    data-testid="input-question-title"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="content">Details</Label>
                  <Textarea
                    id="content"
                    placeholder="Provide more context for your question..."
                    rows={5}
                    value={newQuestion.content}
                    onChange={(e) => setNewQuestion({ ...newQuestion, content: e.target.value })}
                    data-testid="textarea-question-content"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="hashtags">Hashtags (comma-separated)</Label>
                  <Input
                    id="hashtags"
                    placeholder="e.g. consulting, recruiting, McKinsey"
                    value={newQuestion.hashtags}
                    onChange={(e) => setNewQuestion({ ...newQuestion, hashtags: e.target.value })}
                    data-testid="input-question-hashtags"
                  />
                  <p className="text-sm text-muted-foreground">
                    Add hashtags to help others find your question
                  </p>
                </div>

                <div className="flex items-center justify-between py-2 px-4 bg-muted rounded-lg">
                  <div>
                    <Label htmlFor="anonymous" className="text-sm font-medium">
                      Post anonymously
                    </Label>
                    <p className="text-sm text-muted-foreground">
                      Your identity will be hidden from other users
                    </p>
                  </div>
                  <Switch
                    id="anonymous"
                    checked={newQuestion.isAnonymous}
                    onCheckedChange={(checked) =>
                      setNewQuestion({ ...newQuestion, isAnonymous: checked })
                    }
                    data-testid="switch-anonymous"
                  />
                </div>
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAskDialogOpen(false)}>
                  Cancel
                </Button>
                <Button
                  onClick={handleAskQuestion}
                  disabled={createPostMutation.isPending}
                  data-testid="button-submit-question"
                >
                  {createPostMutation.isPending ? "Posting..." : "Post Question"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search discussions by title, content, or hashtags..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            data-testid="input-search-forum"
          />
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="p-6 animate-pulse">
                <div className="h-4 bg-muted rounded w-3/4 mb-4"></div>
                <div className="h-3 bg-muted rounded w-full mb-2"></div>
                <div className="h-3 bg-muted rounded w-2/3"></div>
              </Card>
            ))}
          </div>
        ) : posts.length === 0 ? (
          <Card className="p-12 text-center">
            <MessageSquare className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No questions found</h3>
            <p className="text-muted-foreground mb-4">
              {searchQuery ? "Try adjusting your search" : "Be the first to ask a question!"}
            </p>
            {!searchQuery && (
              <Button onClick={() => setIsAskDialogOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Ask Question
              </Button>
            )}
          </Card>
        ) : (
          <div className="space-y-4">
            {posts.map((post) => {
              const author = getAuthorDisplay(post);
              const responseCount = 0;

              return (
                <Card
                  key={post.id}
                  className="p-6 hover-elevate active-elevate-2 cursor-pointer transition-all"
                  onClick={() => (window.location.href = `/forum/${post.id}`)}
                  data-testid={`card-post-${post.id}`}
                >
                  <div className="flex gap-4">
                    <Avatar className="h-10 w-10 shrink-0">
                      <AvatarFallback>{author.initials}</AvatarFallback>
                    </Avatar>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div>
                          <p className="font-semibold">{author.name}</p>
                          {author.program && (
                            <p className="text-sm text-muted-foreground">{author.program}</p>
                          )}
                        </div>
                        <span className="text-sm text-muted-foreground shrink-0">
                          {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}
                        </span>
                      </div>

                      <h3
                        className="text-lg font-semibold mb-2 text-foreground"
                        data-testid={`text-post-title-${post.id}`}
                      >
                        {post.title}
                      </h3>

                      <p className="text-muted-foreground mb-3 line-clamp-2">
                        {post.content}
                      </p>

                      {post.hashtags.length > 0 && (
                        <div className="flex flex-wrap gap-2 mb-3">
                          {post.hashtags.map((tag, index) => (
                            <Badge
                              key={index}
                              variant="secondary"
                              className="text-xs"
                              data-testid={`badge-hashtag-${tag}`}
                            >
                              <Hash className="h-3 w-3 mr-1" />
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      )}

                      <div className="flex items-center gap-4">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="gap-2"
                          onClick={(e) => {
                            e.stopPropagation();
                            upvoteMutation.mutate(post.id);
                          }}
                          data-testid={`button-upvote-${post.id}`}
                        >
                          <ThumbsUp className="h-4 w-4" />
                          <span>{post.upvotes}</span>
                        </Button>

                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <MessageSquare className="h-4 w-4" />
                          <span data-testid={`text-response-count-${post.id}`}>
                            {responseCount} {responseCount === 1 ? "response" : "responses"}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
