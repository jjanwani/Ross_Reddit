import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { Calendar, MapPin, Clock, Users, Filter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import type { Event } from "@shared/schema";

export default function Events() {
  const [centerFilter, setCenterFilter] = useState("All");
  const [recruitingFilter, setRecruitingFilter] = useState("All");
  const [programFilter, setProgramFilter] = useState("All");
  const [eventTypeFilter, setEventTypeFilter] = useState("All");

  const buildQueryString = () => {
    const params = new URLSearchParams();
    
    if (centerFilter !== "All") params.append("center", centerFilter);
    if (recruitingFilter !== "All") params.append("recruitingFocus", recruitingFilter);
    if (programFilter !== "All") params.append("program", programFilter);
    if (eventTypeFilter !== "All") params.append("eventType", eventTypeFilter);
    
    const queryString = params.toString();
    return queryString ? `/api/events?${queryString}` : "/api/events";
  };

  const { data: events = [], isLoading } = useQuery<Event[]>({
    queryKey: [buildQueryString()],
  });

  const centerOptions = ["All", "Career Development", "Zell", "iMpact", "Erb Institute"];
  const recruitingOptions = ["All", "Tech", "Finance", "Consulting", "Entrepreneurship"];
  const programOptions = ["All", "BBA", "MBA", "All Programs"];
  const eventTypeOptions = ["All", "Career Workshop", "Club Event", "Conference", "Competition", "Networking", "Speaker Event", "Social", "Trek", "Workshop"];

  const formatEventDate = (date: Date | string) => {
    const eventDate = typeof date === "string" ? new Date(date) : date;
    return format(eventDate, "EEE, MMM d, yyyy");
  };

  const formatEventTime = (start: Date | string, end: Date | string | null) => {
    const startDate = typeof start === "string" ? new Date(start) : start;
    const startTime = format(startDate, "h:mm a");
    
    if (!end) return startTime;
    
    const endDate = typeof end === "string" ? new Date(end) : end;
    const endTime = format(endDate, "h:mm a");
    return `${startTime} - ${endTime}`;
  };

  const clearFilters = () => {
    setCenterFilter("All");
    setRecruitingFilter("All");
    setProgramFilter("All");
    setEventTypeFilter("All");
  };

  const hasActiveFilters = centerFilter !== "All" || recruitingFilter !== "All" || 
                          programFilter !== "All" || eventTypeFilter !== "All";

  return (
    <div className="flex-1 overflow-auto">
      <div className="max-w-7xl mx-auto p-6 space-y-6">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div>
            <h1 className="text-4xl font-bold tracking-tight mb-2">Events & Opportunities</h1>
            <p className="text-muted-foreground">
              Discover recruiting events, workshops, and networking opportunities across Ross centers and clubs.
            </p>
          </div>
        </div>

        <Card className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <Filter className="h-5 w-5 text-primary" />
            <h2 className="text-lg font-semibold">Filter Events</h2>
            {hasActiveFilters && (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={clearFilters}
                className="ml-auto"
                data-testid="button-clear-filters"
              >
                Clear Filters
              </Button>
            )}
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="text-sm font-medium text-muted-foreground mb-2 block">
                Center
              </label>
              <Select value={centerFilter} onValueChange={setCenterFilter}>
                <SelectTrigger data-testid="select-center">
                  <SelectValue placeholder="Select center" />
                </SelectTrigger>
                <SelectContent>
                  {centerOptions.map((option) => (
                    <SelectItem key={option} value={option}>
                      {option}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium text-muted-foreground mb-2 block">
                Recruiting Focus
              </label>
              <Select value={recruitingFilter} onValueChange={setRecruitingFilter}>
                <SelectTrigger data-testid="select-recruiting">
                  <SelectValue placeholder="Select focus" />
                </SelectTrigger>
                <SelectContent>
                  {recruitingOptions.map((option) => (
                    <SelectItem key={option} value={option}>
                      {option}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium text-muted-foreground mb-2 block">
                Program
              </label>
              <Select value={programFilter} onValueChange={setProgramFilter}>
                <SelectTrigger data-testid="select-program">
                  <SelectValue placeholder="Select program" />
                </SelectTrigger>
                <SelectContent>
                  {programOptions.map((option) => (
                    <SelectItem key={option} value={option}>
                      {option}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium text-muted-foreground mb-2 block">
                Event Type
              </label>
              <Select value={eventTypeFilter} onValueChange={setEventTypeFilter}>
                <SelectTrigger data-testid="select-event-type">
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  {eventTypeOptions.map((option) => (
                    <SelectItem key={option} value={option}>
                      {option}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </Card>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i} className="p-6 animate-pulse">
                <div className="h-6 bg-muted rounded w-3/4 mb-4"></div>
                <div className="h-4 bg-muted rounded w-full mb-2"></div>
                <div className="h-4 bg-muted rounded w-5/6"></div>
              </Card>
            ))}
          </div>
        ) : events.length === 0 ? (
          <Card className="p-12 text-center">
            <Calendar className="h-16 w-16 mx-auto mb-4 text-muted-foreground opacity-50" />
            <h3 className="text-xl font-semibold mb-2">No events found</h3>
            <p className="text-muted-foreground">
              Try adjusting your filters to see more events.
            </p>
          </Card>
        ) : (
          <>
            <div className="flex items-center justify-between">
              <p className="text-sm text-muted-foreground">
                Showing {events.length} {events.length === 1 ? "event" : "events"}
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {events.map((event) => (
                <Card 
                  key={event.id} 
                  className="p-6 hover-elevate transition-all"
                  data-testid={`card-event-${event.id}`}
                >
                  <div className="space-y-4">
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <h3 className="font-bold text-lg leading-tight" data-testid={`text-event-title-${event.id}`}>
                          {event.title}
                        </h3>
                        <Badge 
                          variant="secondary" 
                          className="text-xs shrink-0"
                          data-testid={`badge-event-type-${event.id}`}
                        >
                          {event.eventType}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground line-clamp-2">
                        {event.description}
                      </p>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <Calendar className="h-4 w-4 text-primary shrink-0" />
                        <span data-testid={`text-event-date-${event.id}`}>
                          {formatEventDate(event.startTime)}
                        </span>
                      </div>
                      
                      <div className="flex items-center gap-2 text-sm">
                        <Clock className="h-4 w-4 text-primary shrink-0" />
                        <span data-testid={`text-event-time-${event.id}`}>
                          {formatEventTime(event.startTime, event.endTime)}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 text-sm">
                        <MapPin className="h-4 w-4 text-primary shrink-0" />
                        <span className="truncate" data-testid={`text-event-location-${event.id}`}>
                          {event.location}
                        </span>
                        <Badge variant="outline" className="text-xs shrink-0">
                          {event.locationType}
                        </Badge>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      {event.center && (
                        <Badge variant="secondary" className="text-xs">
                          {event.center}
                        </Badge>
                      )}
                      {event.recruitingFocus && (
                        <Badge className="text-xs bg-accent text-accent-foreground">
                          {event.recruitingFocus}
                        </Badge>
                      )}
                      {event.program && (
                        <Badge variant="outline" className="text-xs">
                          {event.program}
                        </Badge>
                      )}
                    </div>

                    {event.registrationUrl ? (
                      <Button 
                        asChild
                        className="w-full"
                        data-testid={`button-register-${event.id}`}
                      >
                        <a 
                          href={event.registrationUrl} 
                          target="_blank" 
                          rel="noopener noreferrer"
                        >
                          Register
                        </a>
                      </Button>
                    ) : (
                      <Button 
                        className="w-full"
                        data-testid={`button-register-${event.id}`}
                        disabled
                      >
                        Registration Unavailable
                      </Button>
                    )}
                  </div>
                </Card>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
