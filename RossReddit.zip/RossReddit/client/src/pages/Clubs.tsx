import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Search, Users, TrendingUp, Briefcase, Lightbulb, Heart, Globe, DollarSign, MessageSquare, Award } from "lucide-react";

type Club = {
  name: string;
  category: string;
  description: string;
};

export default function Clubs() {
  const [searchQuery, setSearchQuery] = useState("");

  const clubs: Club[] = [
    // Finance & Investment
    { name: "Alternative Investments Club (AIC)", category: "Finance & Investment", description: "Real estate, private equity, hedge funds, venture capital" },
    { name: "Apex Trading Group", category: "Finance & Investment", description: "Portfolio management and professional development" },
    { name: "Michigan Stocks and Bonds Organization (MSBO)", category: "Finance & Investment", description: "Leading undergraduate investment club" },
    { name: "Quantitative Investment Society", category: "Finance & Investment", description: "Focus on quantitative finance" },
    { name: "Michigan Short-Term Trading (MSTT)", category: "Finance & Investment", description: "Short-term trading strategies" },
    { name: "Michigan Wealth & Asset Management Club", category: "Finance & Investment", description: "First club specializing in wealth management" },
    { name: "BlackGen Capital", category: "Finance & Investment", description: "First minority-owned investment fund at U-M" },
    { name: "First-Generation Investment Group (FGIG)", category: "Finance & Investment", description: "Helping first-gen students enter finance careers" },
    { name: "Investment Banking Club", category: "Finance & Investment", description: "Education and resources for IB careers" },
    { name: "Impact Investing Group", category: "Finance & Investment", description: "Social/environmental impact alongside financial returns" },
    
    // Consulting
    { name: "Ross Consulting Club", category: "Consulting", description: "Largest professional club at Ross, extensive career prep" },
    { name: "Atlas Consulting Group", category: "Consulting", description: "Premier pro-bono undergraduate consulting" },
    { name: "APEX Consulting", category: "Consulting", description: "Student-run consulting for undergrads" },
    { name: "Propel Impact Consulting Group", category: "Consulting", description: "Impact and startup consulting" },
    { name: "180 Degrees Consulting (180DC)", category: "Consulting", description: "Social impact management consulting" },
    { name: "MECC Consulting Group", category: "Consulting", description: "Pro-bono consulting" },
    { name: "BOND Consulting", category: "Consulting", description: "Working with local businesses and non-profits" },
    { name: "Rem and Company", category: "Consulting", description: "Keep small businesses thriving" },
    { name: "Spark", category: "Consulting", description: "Free consulting for minority businesses and non-profits" },
    
    // Technology & AI
    { name: "AI Business Group", category: "Technology & AI", description: "Only club focused on AI for business problems" },
    { name: "MBA FinTech Club at Michigan Ross (MFCM)", category: "Technology & AI", description: "FinTech education and networking" },
    { name: "Ross Consulting Group (RCG)", category: "Technology & AI", description: "Digital design and data intersection" },
    
    // Marketing
    { name: "BBA Marketing Club", category: "Marketing", description: "Largest undergraduate marketing organization (120+ members)" },
    { name: "Marketing Lab", category: "Marketing", description: "Access to Nielsen, Tracx, and other professional marketing tools" },
    
    // Diversity & Identity
    { name: "Black Business Students Association (BBSA)", category: "Diversity & Identity", description: "Founded 1970, one of largest at Ross" },
    { name: "Ross African Business Club", category: "Diversity & Identity", description: "Support for African students and business opportunities in Africa" },
    { name: "Asia Business Conference (ABC)", category: "Diversity & Identity", description: "Longest student-run conference in North America focused on Asia (30+ years)" },
    { name: "Asian MBA Association (AMBA)", category: "Diversity & Identity", description: "Cultural diversity and inclusion" },
    { name: "ALPFA", category: "Diversity & Identity", description: "Latino leadership in global markets" },
    { name: "Michigan Business Women (MBW)", category: "Diversity & Identity", description: "Women's personal and professional development" },
    { name: "Out for Business (OFB)", category: "Diversity & Identity", description: "LGBTQ+ student association" },
    { name: "Ross Armed Forces Association", category: "Diversity & Identity", description: "Veteran advancement in business" },
    
    // Entrepreneurship & Innovation
    { name: "Michigan Venture Lab", category: "Entrepreneurship & Innovation", description: "Programs, mentorship, and funding for student projects" },
    { name: "China Entrepreneur Network (CEN)", category: "Entrepreneurship & Innovation", description: "University alliance founded at U-M in 2009" },
    { name: "Design+Business (D+B)", category: "Entrepreneurship & Innovation", description: "Design methodologies for organizational leadership" },
    { name: "Michigan Climate Venture (MCV)", category: "Entrepreneurship & Innovation", description: "Climate-focused ventures" },
    
    // Social Impact & Sustainability
    { name: "Net Impact @ Ross (NI@R)", category: "Social Impact & Sustainability", description: "Positive business and societal impact" },
    { name: "Emerging Markets Club (EMC)", category: "Social Impact & Sustainability", description: "Education on emerging markets" },
    { name: "Detroit Initiative", category: "Social Impact & Sustainability", description: "Detroit community engagement" },
    { name: "Smart Cities Club", category: "Social Impact & Sustainability", description: "Smart cities sector learning" },
    { name: "Energy Club", category: "Social Impact & Sustainability", description: "Energy industry career development and renewable energy" },
    { name: "M-HEAL", category: "Social Impact & Sustainability", description: "Global health and design with underserved communities" },
    
    // Accounting & Professional Fraternities
    { name: "Alpha Kappa Psi", category: "Professional Fraternities", description: "Professional co-ed business fraternity" },
    { name: "Beta Alpha Psi", category: "Professional Fraternities", description: "Accounting, corporate finance professional development" },
    { name: "Accounting Club", category: "Professional Fraternities", description: "Professional accounting discipline promotion" },
    
    // Other
    { name: "Adam Smith Society", category: "Other", description: "Free market economic system discussions" },
  ];

  const categories = Array.from(new Set(clubs.map(club => club.category)));

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "Finance & Investment": return DollarSign;
      case "Consulting": return Briefcase;
      case "Technology & AI": return TrendingUp;
      case "Marketing": return MessageSquare;
      case "Diversity & Identity": return Users;
      case "Entrepreneurship & Innovation": return Lightbulb;
      case "Social Impact & Sustainability": return Heart;
      case "Professional Fraternities": return Award;
      default: return Globe;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "Finance & Investment": return "bg-green-500/10 text-green-700 dark:text-green-300";
      case "Consulting": return "bg-blue-500/10 text-blue-700 dark:text-blue-300";
      case "Technology & AI": return "bg-purple-500/10 text-purple-700 dark:text-purple-300";
      case "Marketing": return "bg-pink-500/10 text-pink-700 dark:text-pink-300";
      case "Diversity & Identity": return "bg-orange-500/10 text-orange-700 dark:text-orange-300";
      case "Entrepreneurship & Innovation": return "bg-yellow-500/10 text-yellow-700 dark:text-yellow-300";
      case "Social Impact & Sustainability": return "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300";
      case "Professional Fraternities": return "bg-indigo-500/10 text-indigo-700 dark:text-indigo-300";
      default: return "bg-gray-500/10 text-gray-700 dark:text-gray-300";
    }
  };

  const filteredClubs = clubs.filter(club =>
    club.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    club.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    club.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const clubsByCategory = categories.map(category => ({
    category,
    clubs: filteredClubs.filter(club => club.category === category)
  })).filter(group => group.clubs.length > 0);

  return (
    <div className="flex-1 overflow-auto">
      <div className="mx-auto max-w-7xl px-6 md:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-3">Ross School Clubs & Organizations</h1>
          <p className="text-lg text-muted-foreground mb-6">
            Explore over 135+ student clubs and organizations at Michigan Ross. Connect with peers, develop professionally, and pursue your passions.
          </p>
          
          {/* Search */}
          <div className="relative max-w-xl">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search clubs by name, description, or category..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
              data-testid="input-search-clubs"
            />
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
          <Card className="p-6">
            <div className="flex items-center gap-3">
              <div className="bg-primary/10 text-primary rounded-lg p-3">
                <Users className="h-6 w-6" />
              </div>
              <div>
                <p className="text-2xl font-bold">{clubs.length}</p>
                <p className="text-sm text-muted-foreground">Total Clubs</p>
              </div>
            </div>
          </Card>
          <Card className="p-6">
            <div className="flex items-center gap-3">
              <div className="bg-primary/10 text-primary rounded-lg p-3">
                <Globe className="h-6 w-6" />
              </div>
              <div>
                <p className="text-2xl font-bold">{categories.length}</p>
                <p className="text-sm text-muted-foreground">Categories</p>
              </div>
            </div>
          </Card>
          <Card className="p-6">
            <div className="flex items-center gap-3">
              <div className="bg-primary/10 text-primary rounded-lg p-3">
                <TrendingUp className="h-6 w-6" />
              </div>
              <div>
                <p className="text-2xl font-bold">1,400+</p>
                <p className="text-sm text-muted-foreground">Total U-M Orgs</p>
              </div>
            </div>
          </Card>
        </div>

        {/* External Link */}
        <Card className="p-6 mb-8 bg-accent text-accent-foreground">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h3 className="font-semibold mb-2">Looking for more organizations?</h3>
              <p className="text-sm mb-3">
                Visit Maize Pages to explore all 1,400+ student organizations across the University of Michigan.
              </p>
              <a 
                href="https://maizepages.umich.edu/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-sm font-medium underline hover:no-underline"
                data-testid="link-maize-pages"
              >
                Visit Maize Pages →
              </a>
            </div>
          </div>
        </Card>

        {/* Clubs by Category */}
        {clubsByCategory.length > 0 ? (
          <div className="space-y-8">
            {clubsByCategory.map(({ category, clubs: categoryClubs }) => {
              const Icon = getCategoryIcon(category);
              return (
                <div key={category}>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="bg-primary/10 text-primary rounded-lg p-2">
                      <Icon className="h-5 w-5" />
                    </div>
                    <h2 className="text-2xl font-bold">{category}</h2>
                    <Badge variant="secondary" className="ml-2">
                      {categoryClubs.length}
                    </Badge>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {categoryClubs.map((club, index) => (
                      <Card 
                        key={`${club.name}-${index}`} 
                        className="p-5 hover-elevate active-elevate-2 transition-all"
                        data-testid={`card-club-${index}`}
                      >
                        <div className="flex flex-col gap-3">
                          <div className="flex items-start justify-between gap-2">
                            <h3 className="font-semibold text-base leading-tight flex-1">
                              {club.name}
                            </h3>
                            <Badge 
                              variant="secondary" 
                              className={`text-xs ${getCategoryColor(club.category)} shrink-0`}
                            >
                              {club.category.split(' ')[0]}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            {club.description}
                          </p>
                        </div>
                      </Card>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <Card className="p-12 text-center">
            <Search className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No clubs found</h3>
            <p className="text-muted-foreground">
              Try adjusting your search terms or browse all categories.
            </p>
          </Card>
        )}
      </div>
    </div>
  );
}
