import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  MessageSquare, 
  Calendar, 
  BookOpen, 
  Users, 
  ArrowRight,
  Bell,
  TrendingUp
} from "lucide-react";
import heroImage from "@assets/stock_images/rossbuilding.png";

export default function Home() {
  const navigationCards = [
    {
      id: "forum",
      title: "Forum Discussions",
      description: "Ask questions, share insights, and connect with peers",
      icon: MessageSquare,
      path: "/forum",
      color: "bg-primary",
    },
    {
      id: "events",
      title: "Upcoming Events",
      description: "Discover networking events and opportunities",
      icon: Calendar,
      path: "/events",
      color: "bg-primary",
    },
    {
      id: "resources",
      title: "Resource Library",
      description: "Access recruiting materials and study guides",
      icon: BookOpen,
      path: "/resources",
      color: "bg-primary",
    },
    {
      id: "mentorship",
      title: "Mentorship Network",
      description: "Connect with upperclassmen mentors in your field",
      icon: Users,
      path: "/mentorship",
      color: "bg-primary",
    },
  ];

  const quickActions = [
    { title: "Post a Question", path: "/forum", badge: null },
    { title: "My Mentorship Matches", path: "/mentorship", badge: "2 active" },
    { title: "Upcoming Events", path: "/events", badge: "3 this week" },
    { title: "Trending Topics", path: "/forum", badge: null },
  ];

  const announcements = [
    {
      title: "Fall Recruiting Workshop - Tomorrow at 6 PM",
      category: "Event",
    },
    {
      title: "New Resource: IB Interview Prep Guide",
      category: "Resource",
    },
  ];

  return (
    <div className="flex-1">
      {/* Hero Section */}
      <div className="relative bg-primary text-primary-foreground overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${heroImage})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-br from-primary/90 via-primary/85 to-primary/80" />
        <div className="relative mx-auto max-w-7xl px-6 md:px-8 py-16 md:py-24">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">
              Welcome to Michigan Ross Reddit
            </h1>
            <p className="text-lg md:text-xl opacity-90 mb-8">
              Ross Reddit is the web portal for the Ross School of Business at the University of Michigan. 
              Connect with mentors, access resources, and engage with your community.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link href="/forum">
                <Button 
                  size="lg" 
                  variant="secondary"
                  className="gap-2"
                  data-testid="button-get-started"
                >
                  Get Started
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
              <Link href="/events">
                <Button 
                  size="lg" 
                  variant="outline"
                  className="gap-2 border-primary-foreground text-primary-foreground backdrop-blur-sm"
                  data-testid="button-explore-events"
                >
                  Explore Events
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="mx-auto max-w-7xl px-6 md:px-8 py-12">
        {/* Important Announcements Banner */}
        <div className="mb-8">
          <div className="flex items-center justify-between gap-4 bg-accent text-accent-foreground rounded-xl p-4 shadow-md">
            <div className="flex items-center gap-3">
              <Bell className="h-5 w-5" />
              <span className="font-semibold">Important Announcements</span>
            </div>
            <Button 
              size="icon" 
              variant="ghost" 
              className="h-8 w-8 text-accent-foreground"
              data-testid="button-expand-announcements"
            >
              <ArrowRight className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Navigation Cards */}
          <div className="lg:col-span-2">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {navigationCards.map((card) => {
                const Icon = card.icon;
                return (
                  <Link key={card.id} href={card.path}>
                    <Card 
                      className="p-8 hover-elevate active-elevate-2 cursor-pointer transition-all h-full min-h-48 shadow-md hover:shadow-lg"
                      data-testid={`card-nav-${card.id}`}
                    >
                      <div className="flex flex-col items-center text-center gap-4">
                        <div className={`${card.color} text-primary-foreground rounded-full p-4`}>
                          <Icon className="h-12 w-12" />
                        </div>
                        <div>
                          <h3 className="text-xl font-semibold mb-2">{card.title}</h3>
                          <p className="text-sm text-muted-foreground">{card.description}</p>
                        </div>
                        <ArrowRight className="h-5 w-5 text-muted-foreground mt-auto" />
                      </div>
                    </Card>
                  </Link>
                );
              })}
            </div>

            {/* Recent Activity Section */}
            <div className="mt-12">
              <h2 className="text-2xl font-bold mb-6">Recent Community Activity</h2>
              <div className="space-y-4">
                <Card className="p-6">
                  <div className="flex items-start gap-4">
                    <MessageSquare className="h-5 w-5 text-primary mt-1" />
                    <div className="flex-1">
                      <h4 className="font-semibold mb-1">Tips for McKinsey first round interviews?</h4>
                      <p className="text-sm text-muted-foreground mb-2">
                        Sarah Chen posted in Consulting • 2h ago
                      </p>
                      <div className="flex gap-2">
                        <Badge variant="secondary" className="text-xs">consulting</Badge>
                        <Badge variant="secondary" className="text-xs">recruiting</Badge>
                      </div>
                    </div>
                    <span className="text-sm font-medium text-muted-foreground">24 ↑</span>
                  </div>
                </Card>

                <Card className="p-6">
                  <div className="flex items-start gap-4">
                    <TrendingUp className="h-5 w-5 text-accent mt-1" />
                    <div className="flex-1">
                      <h4 className="font-semibold mb-1">Best coding practice resources for PM interviews?</h4>
                      <p className="text-sm text-muted-foreground mb-2">
                        David Kim posted in Tech • 1d ago
                      </p>
                      <div className="flex gap-2">
                        <Badge variant="secondary" className="text-xs">tech</Badge>
                        <Badge variant="secondary" className="text-xs">PM</Badge>
                      </div>
                    </div>
                    <span className="text-sm font-medium text-muted-foreground">18 ↑</span>
                  </div>
                </Card>
              </div>
            </div>
          </div>

          {/* Right Sidebar - Quick Actions */}
          <div className="lg:col-span-1">
            <div className="sticky top-24 z-50 space-y-6">
              {/* Quick Start */}
              <Card className="p-6 bg-primary text-primary-foreground shadow-lg">
                <div className="flex items-center gap-2 mb-4">
                  <div className="bg-accent text-accent-foreground rounded-lg p-2">
                    <ArrowRight className="h-5 w-5" />
                  </div>
                  <h3 className="text-lg font-bold">Quick Start</h3>
                </div>
                <p className="text-sm opacity-90 mb-4">
                  New to Ross Reddit? Start here to make the most of your experience.
                </p>
                <Link href="/forum">
                  <Button 
                    variant="secondary" 
                    className="w-full"
                    data-testid="button-quick-start"
                  >
                    Get Started
                  </Button>
                </Link>
              </Card>

              {/* My iMpact Profile */}
              <Card className="p-6 shadow-md">
                <h3 className="font-semibold mb-4">My iMpact Profile</h3>
                <Link href="/profile">
                  <Button 
                    variant="outline" 
                    className="w-full"
                    data-testid="button-my-profile"
                  >
                    View Profile
                  </Button>
                </Link>
              </Card>

              {/* Ross Commitment to Care */}
              <Card className="p-6 bg-accent text-accent-foreground shadow-md">
                <h3 className="font-semibold mb-2">Ross Commitment to Care</h3>
                <p className="text-sm mb-4">
                  Supporting our community's wellbeing and success.
                </p>
                <Button 
                  variant="outline" 
                  size="sm"
                  className="w-full border-accent-foreground text-accent-foreground"
                  data-testid="button-commitment-care"
                >
                  Learn More
                </Button>
              </Card>

              {/* Quick Actions */}
              <Card className="p-6 shadow-md">
                <h3 className="font-semibold mb-4">Quick Actions</h3>
                <div className="space-y-2">
                  {quickActions.map((action, index) => (
                    <Link key={index} href={action.path}>
                      <Button 
                        variant="ghost" 
                        className="w-full justify-start hover-elevate"
                        data-testid={`button-quick-${index}`}
                      >
                        <span className="flex-1 text-left">{action.title}</span>
                        {action.badge && (
                          <Badge variant="secondary" className="text-xs">
                            {action.badge}
                          </Badge>
                        )}
                      </Button>
                    </Link>
                  ))}
                </div>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
