import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Search, Send, PlusCircle } from "lucide-react";
import type { Message, UserProfile } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { format } from "date-fns";

const CURRENT_USER_ID = "user1";

export default function Messages() {
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [newMessage, setNewMessage] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [centerFilter, setCenterFilter] = useState<string>("");
  const [careerFilter, setCareerFilter] = useState<string>("");
  const [programFilter, setProgramFilter] = useState<string>("");
  const [isNewMessageOpen, setIsNewMessageOpen] = useState(false);

  const { data: allMessages = [], isLoading: messagesLoading } = useQuery<Message[]>({
    queryKey: ["/api/messages", CURRENT_USER_ID],
    queryFn: () => fetch(`/api/messages?userId=${CURRENT_USER_ID}`).then(res => res.json()),
  });

  const { data: currentUserProfile } = useQuery<UserProfile>({
    queryKey: ["/api/profiles", CURRENT_USER_ID],
  });

  const { data: conversation = [] } = useQuery<Message[]>({
    queryKey: ["/api/conversations", CURRENT_USER_ID, selectedUserId],
    enabled: !!selectedUserId,
  });

  const conversationPartners = Array.from(
    new Set(
      allMessages.map(m =>
        m.senderId === CURRENT_USER_ID ? m.recipientId : m.senderId
      )
    )
  );

  const { data: partnerProfiles = [] } = useQuery<UserProfile[]>({
    queryKey: ["/api/profiles/partners", conversationPartners],
    queryFn: async () => {
      const profiles = await Promise.all(
        conversationPartners.map(userId =>
          fetch(`/api/profiles/${userId}`).then(res => res.json())
        )
      );
      return profiles;
    },
    enabled: conversationPartners.length > 0,
  });

  const buildSearchURL = () => {
    const params = new URLSearchParams();
    if (centerFilter && centerFilter !== "all") params.append("rossCenter", centerFilter);
    if (careerFilter && careerFilter !== "all") params.append("careerInterests", careerFilter);
    if (programFilter && programFilter !== "all") params.append("program", programFilter);
    const queryString = params.toString();
    return queryString ? `/api/profiles?${queryString}` : "/api/profiles";
  };

  const { data: searchResults = [] } = useQuery<UserProfile[]>({
    queryKey: [buildSearchURL()],
    enabled: isNewMessageOpen,
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      if (!selectedUserId) {
        throw new Error("No recipient selected");
      }
      return apiRequest("POST", "/api/messages", {
        senderId: CURRENT_USER_ID,
        recipientId: selectedUserId,
        content,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/messages"] });
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
      setNewMessage("");
    },
  });

  const startNewConversation = (userId: string) => {
    setSelectedUserId(userId);
    setIsNewMessageOpen(false);
  };

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      sendMessageMutation.mutate(newMessage);
    }
  };

  const getConversationPreview = (userId: string): Message | undefined => {
    return allMessages
      .filter(m => 
        (m.senderId === userId && m.recipientId === CURRENT_USER_ID) ||
        (m.recipientId === userId && m.senderId === CURRENT_USER_ID)
      )
      .sort((a, b) => new Date(b.sentAt).getTime() - new Date(a.sentAt).getTime())[0];
  };

  const filteredSearchResults = searchResults
    .filter(profile => 
      profile.userId !== CURRENT_USER_ID &&
      profile.fullName.toLowerCase().includes(searchQuery.toLowerCase())
    );

  const selectedProfile = partnerProfiles.find(p => p.userId === selectedUserId);

  if (messagesLoading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <p className="text-muted-foreground">Loading messages...</p>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-hidden flex">
      <div className="w-80 border-r flex flex-col">
        <div className="p-4 border-b space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold">Messages</h2>
            <Dialog open={isNewMessageOpen} onOpenChange={setIsNewMessageOpen}>
              <DialogTrigger asChild>
                <Button size="icon" variant="ghost" data-testid="button-new-message">
                  <PlusCircle className="h-5 w-5" />
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>New Message</DialogTitle>
                  <DialogDescription>
                    Search for Ross students by center, career interests, or program
                  </DialogDescription>
                </DialogHeader>

                <div className="space-y-4">
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search by name..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-9"
                        data-testid="input-search-users"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <Select value={centerFilter} onValueChange={setCenterFilter}>
                      <SelectTrigger data-testid="select-center-filter">
                        <SelectValue placeholder="Ross Center" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Centers</SelectItem>
                        <SelectItem value="Zell">Zell</SelectItem>
                        <SelectItem value="iMpact">iMpact</SelectItem>
                        <SelectItem value="Career Development">Career Development</SelectItem>
                        <SelectItem value="Erb Institute">Erb Institute</SelectItem>
                      </SelectContent>
                    </Select>

                    <Select value={careerFilter} onValueChange={setCareerFilter}>
                      <SelectTrigger data-testid="select-career-filter">
                        <SelectValue placeholder="Career Interest" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Interests</SelectItem>
                        <SelectItem value="Tech">Tech</SelectItem>
                        <SelectItem value="Finance">Finance</SelectItem>
                        <SelectItem value="Consulting">Consulting</SelectItem>
                        <SelectItem value="Entrepreneurship">Entrepreneurship</SelectItem>
                        <SelectItem value="Social Impact">Social Impact</SelectItem>
                      </SelectContent>
                    </Select>

                    <Select value={programFilter} onValueChange={setProgramFilter}>
                      <SelectTrigger data-testid="select-program-filter">
                        <SelectValue placeholder="Program" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Programs</SelectItem>
                        <SelectItem value="BBA">BBA</SelectItem>
                        <SelectItem value="MBA">MBA</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="max-h-96 overflow-y-auto space-y-2">
                    {filteredSearchResults.map((profile) => (
                      <Card
                        key={profile.id}
                        className="p-3 hover-elevate active-elevate-2 cursor-pointer"
                        onClick={() => startNewConversation(profile.userId)}
                        data-testid={`user-card-${profile.userId}`}
                      >
                        <div className="flex items-center gap-3">
                          <Avatar className="h-10 w-10">
                            <AvatarImage src={profile.avatarUrl || undefined} />
                            <AvatarFallback>
                              {profile.fullName.split(" ").map(n => n[0]).join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <p className="font-semibold text-sm">{profile.fullName}</p>
                            <p className="text-xs text-muted-foreground truncate">
                              {profile.program} '{profile.graduationYear.slice(-2)}
                            </p>
                          </div>
                          <div className="flex flex-wrap gap-1">
                            {profile.careerInterests.slice(0, 2).map(interest => (
                              <Badge key={interest} variant="secondary" className="text-xs">
                                {interest}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        {profile.bio && (
                          <p className="text-xs text-muted-foreground mt-2 line-clamp-2">
                            {profile.bio}
                          </p>
                        )}
                      </Card>
                    ))}
                    {filteredSearchResults.length === 0 && (
                      <div className="text-center py-8 text-muted-foreground">
                        No students found. Try adjusting your filters.
                      </div>
                    )}
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          {conversationPartners.length === 0 ? (
            <div className="p-4 text-center text-muted-foreground">
              <p>No conversations yet</p>
              <p className="text-sm mt-1">Start a new message to connect</p>
            </div>
          ) : (
            <div className="space-y-1 p-2">
              {conversationPartners.map((userId) => {
                const profile = partnerProfiles.find(p => p.userId === userId);
                const lastMessage = getConversationPreview(userId);
                const isUnread = lastMessage && lastMessage.recipientId === CURRENT_USER_ID && lastMessage.isRead === "false";

                if (!profile) return null;

                return (
                  <Card
                    key={userId}
                    className={`p-3 hover-elevate active-elevate-2 cursor-pointer ${
                      selectedUserId === userId ? "bg-accent" : ""
                    }`}
                    onClick={() => setSelectedUserId(userId)}
                    data-testid={`conversation-${userId}`}
                  >
                    <div className="flex items-start gap-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={profile.avatarUrl || undefined} />
                        <AvatarFallback>
                          {profile.fullName.split(" ").map(n => n[0]).join("")}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <p className={`font-semibold text-sm ${isUnread ? "text-primary" : ""}`}>
                            {profile.fullName}
                          </p>
                          {lastMessage && (
                            <span className="text-xs text-muted-foreground">
                              {format(new Date(lastMessage.sentAt), "MMM d")}
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground">
                          {profile.program} '{profile.graduationYear.slice(-2)}
                        </p>
                        {lastMessage && (
                          <p className={`text-sm mt-1 truncate ${isUnread ? "font-medium" : "text-muted-foreground"}`}>
                            {lastMessage.senderId === CURRENT_USER_ID ? "You: " : ""}
                            {lastMessage.content}
                          </p>
                        )}
                      </div>
                      {isUnread && (
                        <div className="h-2 w-2 rounded-full bg-primary" />
                      )}
                    </div>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      </div>

      <div className="flex-1 flex flex-col">
        {selectedUserId && selectedProfile ? (
          <>
            <div className="p-4 border-b">
              <div className="flex items-center gap-3">
                <Avatar className="h-10 w-10">
                  <AvatarImage src={selectedProfile.avatarUrl || undefined} />
                  <AvatarFallback>
                    {selectedProfile.fullName.split(" ").map(n => n[0]).join("")}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <h3 className="font-semibold" data-testid="text-conversation-name">
                    {selectedProfile.fullName}
                  </h3>
                  <p className="text-xs text-muted-foreground">
                    {selectedProfile.program} '{selectedProfile.graduationYear.slice(-2)} • {selectedProfile.careerInterests.join(", ")}
                  </p>
                </div>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {conversation.map((message) => {
                const isCurrentUser = message.senderId === CURRENT_USER_ID;
                return (
                  <div
                    key={message.id}
                    className={`flex gap-3 ${isCurrentUser ? "flex-row-reverse" : ""}`}
                  >
                    {!isCurrentUser && (
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={selectedProfile.avatarUrl || undefined} />
                        <AvatarFallback>
                          {selectedProfile.fullName.split(" ").map(n => n[0]).join("")}
                        </AvatarFallback>
                      </Avatar>
                    )}
                    <div
                      className={`flex flex-col ${isCurrentUser ? "items-end" : "items-start"} max-w-[70%]`}
                    >
                      <div
                        className={`rounded-lg px-4 py-2 ${
                          isCurrentUser
                            ? "bg-primary text-primary-foreground"
                            : "bg-muted"
                        }`}
                        data-testid={`message-${message.id}`}
                      >
                        <p className="text-sm">{message.content}</p>
                      </div>
                      <span className="text-xs text-muted-foreground mt-1">
                        {format(new Date(message.sentAt), "h:mm a")}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="p-4 border-t">
              <div className="flex gap-2">
                <Input
                  placeholder="Type a message..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessage();
                    }
                  }}
                  data-testid="input-message"
                />
                <Button
                  onClick={handleSendMessage}
                  size="icon"
                  disabled={!newMessage.trim() || sendMessageMutation.isPending}
                  data-testid="button-send"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <p className="text-muted-foreground mb-4">Select a conversation to start messaging</p>
              <Button onClick={() => setIsNewMessageOpen(true)} data-testid="button-start-conversation">
                <PlusCircle className="h-4 w-4 mr-2" />
                Start New Conversation
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
