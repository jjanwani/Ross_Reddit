import { useState } from "react";
import { Plus, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SearchBar } from "@/components/SearchBar";
import { FilterChips } from "@/components/FilterChips";
import { ResourceCard } from "@/components/ResourceCard";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { ObjectUploader } from "@/components/ObjectUploader";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertResourceSchema, type Resource, type InsertResource } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import type { UploadResult } from "@uppy/core";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

const categories = ["All", "Classes", "Recruitment", "Clubs", "Tech", "Consulting", "Finance", "Entrepreneurship"];

export default function Resources() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
  const { toast } = useToast();

  const { data: resources = [], isLoading } = useQuery<Resource[]>({
    queryKey: ["/api/resources", selectedCategory, searchQuery],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (selectedCategory !== "All") {
        params.set("category", selectedCategory);
      }
      if (searchQuery) {
        params.set("search", searchQuery);
      }
      const query = params.toString();
      return fetch(`/api/resources${query ? `?${query}` : ""}`).then((r) => r.json());
    },
  });

  const form = useForm<InsertResource>({
    resolver: zodResolver(
      insertResourceSchema.omit({ 
        id: true, 
        createdAt: true,
        upvotes: true,
        downloadCount: true,
      })
    ),
    defaultValues: {
      uploaderId: "user1",
      title: "",
      description: "",
      category: "Classes",
      filePath: "",
      fileName: "",
      fileSize: "",
    },
  });

  const createResourceMutation = useMutation({
    mutationFn: async (data: InsertResource) => {
      const response = await apiRequest("POST", "/api/resources", data);
      return response.json() as Promise<Resource>;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/resources"] });
      toast({
        title: "Success",
        description: "Resource uploaded successfully",
      });
      form.reset();
      setUploadDialogOpen(false);
    },
    onError: (error: Error) => {
      const errorMessage = error.message || "Failed to upload resource";
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    },
  });

  const handleUploadComplete = (result: UploadResult<Record<string, unknown>, Record<string, unknown>>) => {
    if (result.failed && result.failed.length > 0) {
      const failedFile = result.failed[0];
      const errorMessage = failedFile.error || "Unknown error occurred";
      toast({
        title: "Upload Failed",
        description: `Failed to upload file: ${errorMessage}`,
        variant: "destructive",
      });
      return;
    }

    if (result.successful.length > 0) {
      const file = result.successful[0];
      const uploadedFile = file.response?.uploadURL as string;
      
      if (uploadedFile) {
        const fileName = file.name || "unknown";
        const fileSize = String(file.size || 0);
        
        const normalizedPath = uploadedFile.split("?")[0];
        const pathParts = normalizedPath.split("/");
        const objectId = pathParts[pathParts.length - 1];
        const filePath = `/objects/uploads/${objectId}`;
        
        form.setValue("filePath", filePath);
        form.setValue("fileName", fileName);
        form.setValue("fileSize", fileSize);
        
        toast({
          title: "File uploaded",
          description: "You can now complete the form and submit",
        });
      } else {
        toast({
          title: "Upload Error",
          description: "File uploaded but no URL was returned",
          variant: "destructive",
        });
      }
    }
  };

  const handleFormSubmit = form.handleSubmit((data) => {
    if (!data.filePath || !data.fileName) {
      toast({
        title: "Error",
        description: "Please upload a file first",
        variant: "destructive",
      });
      return;
    }
    createResourceMutation.mutate(data);
  });

  return (
    <div className="flex-1 overflow-auto">
      <div className="max-w-4xl mx-auto p-6 space-y-6">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div>
            <h1 className="text-4xl font-bold tracking-tight mb-2">Resources</h1>
            <p className="text-muted-foreground">
              Access recruiting guides, class notes, and student-created materials.
            </p>
          </div>
          
          <Dialog open={uploadDialogOpen} onOpenChange={setUploadDialogOpen}>
            <DialogTrigger asChild>
              <Button data-testid="button-upload-resource">
                <Plus className="h-4 w-4 mr-2" />
                Upload Resource
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Upload Resource</DialogTitle>
                <DialogDescription>
                  Share study guides, recruiting materials, or other helpful documents with the Ross community.
                </DialogDescription>
              </DialogHeader>
              
              <Form {...form}>
                <form onSubmit={handleFormSubmit} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Title</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="e.g., ACC 300 Final Exam Study Guide"
                            data-testid="input-resource-title"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Describe what this resource contains and who might find it helpful..."
                            data-testid="input-resource-description"
                            rows={3}
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="category"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Category</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger data-testid="select-resource-category">
                              <SelectValue placeholder="Select a category" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {categories.filter(c => c !== "All").map((category) => (
                              <SelectItem key={category} value={category}>
                                {category}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="space-y-2">
                    <label className="text-sm font-medium">File Upload</label>
                    <ObjectUploader
                      maxNumberOfFiles={1}
                      maxFileSize={10485760}
                      onGetUploadParameters={async () => {
                        const response = await fetch("/api/upload-url", {
                          method: "POST",
                          credentials: "include",
                        });
                        const { url } = await response.json();
                        return { method: "PUT" as const, url };
                      }}
                      onComplete={handleUploadComplete}
                      buttonClassName="w-full"
                    >
                      {form.watch("filePath") ? "Change File" : "Choose File"}
                    </ObjectUploader>
                    {form.watch("fileName") && (
                      <p className="text-sm text-muted-foreground">
                        Selected: {form.watch("fileName")}
                      </p>
                    )}
                  </div>

                  <div className="flex gap-2 justify-end pt-4">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => {
                        form.reset();
                        setUploadDialogOpen(false);
                      }}
                      data-testid="button-cancel-upload"
                    >
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      disabled={createResourceMutation.isPending}
                      data-testid="button-submit-resource"
                    >
                      {createResourceMutation.isPending && (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      )}
                      Upload Resource
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>

        <SearchBar 
          placeholder="Search resources..." 
          value={searchQuery}
          onChange={setSearchQuery}
          data-testid="input-search-resources"
        />

        <FilterChips
          availableFilters={categories}
          selectedFilter={selectedCategory}
          onFilterChange={setSelectedCategory}
        />

        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <div className="space-y-3">
                    <Skeleton className="h-6 w-3/4" />
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-1/2" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : resources.length === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <p className="text-muted-foreground">
                No resources found. Be the first to contribute!
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {resources.map((resource) => (
              <ResourceCard key={resource.id} {...resource} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
