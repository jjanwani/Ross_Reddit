import { Link, useLocation } from "wouter";
import { Search, Bell, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";

export function TopNavigation() {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { title: "Forum", path: "/forum" },
    { title: "Events", path: "/events" },
    { title: "Resources", path: "/resources" },
    { title: "Mentorship", path: "/mentorship" },
    { title: "Clubs", path: "/clubs" },
    { title: "Messages", path: "/messages" },
  ];

  const isActive = (path: string) => location === path;

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-primary text-primary-foreground">
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-6 md:px-8">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-3 hover-elevate active-elevate-2 rounded-lg px-3 py-2" data-testid="link-home">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent text-accent-foreground">
            <span className="text-xl font-bold">M</span>
          </div>
          <div className="hidden sm:block">
            <h1 className="text-lg font-bold leading-none">Ross Reddit</h1>
            <p className="text-xs opacity-90">Michigan Ross</p>
          </div>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-2">
          {navItems.map((item) => (
            <Link key={item.path} href={item.path}>
              <Button
                variant="ghost"
                className={`text-primary-foreground ${
                  isActive(item.path) ? "bg-primary-foreground/20" : ""
                }`}
                data-testid={`link-${item.title.toLowerCase()}`}
              >
                {item.title}
              </Button>
            </Link>
          ))}
        </nav>

        {/* Right Actions */}
        <div className="flex items-center gap-2">
          <Button
            size="icon"
            variant="ghost"
            className="text-primary-foreground"
            data-testid="button-search"
          >
            <Search className="h-5 w-5" />
          </Button>
          <Button
            size="icon"
            variant="ghost"
            className="text-primary-foreground relative"
            data-testid="button-notifications"
          >
            <Bell className="h-5 w-5" />
            <Badge className="absolute -right-1 -top-1 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
              3
            </Badge>
          </Button>
          <Link href="/profile">
            <Avatar className="h-10 w-10 cursor-pointer hover-elevate active-elevate-2" data-testid="button-profile">
              <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=user1" />
              <AvatarFallback>JD</AvatarFallback>
            </Avatar>
          </Link>

          {/* Mobile Menu Button */}
          <Button
            size="icon"
            variant="ghost"
            className="lg:hidden text-primary-foreground"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            data-testid="button-mobile-menu"
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-primary-foreground/20">
          <nav className="flex flex-col p-4 gap-2">
            {navItems.map((item) => (
              <Link key={item.path} href={item.path} onClick={() => setMobileMenuOpen(false)}>
                <Button
                  variant="ghost"
                  className={`w-full justify-start text-primary-foreground ${
                    isActive(item.path) ? "bg-primary-foreground/20" : ""
                  }`}
                  data-testid={`link-mobile-${item.title.toLowerCase()}`}
                >
                  {item.title}
                </Button>
              </Link>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
}
