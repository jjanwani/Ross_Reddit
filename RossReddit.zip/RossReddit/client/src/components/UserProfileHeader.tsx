import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Settings, Mail } from "lucide-react";

interface UserProfileHeaderProps {
  name: string;
  avatar?: string;
  email: string;
  year: string;
  major: string;
  interests: string[];
  bio: string;
  role: "mentee" | "mentor" | "both";
}

export function UserProfileHeader({
  name,
  avatar,
  email,
  year,
  major,
  interests,
  bio,
  role,
}: UserProfileHeaderProps) {
  const initials = name
    .split(" ")
    .map((n) => n[0])
    .join("");

  const roleLabel = role === "both" ? "Mentor & Mentee" : role === "mentor" ? "Mentor" : "Mentee";

  return (
    <div className="bg-card border-b p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex flex-col md:flex-row gap-6 items-start">
          <Avatar className="h-32 w-32">
            <AvatarImage src={avatar} />
            <AvatarFallback className="text-4xl">{initials}</AvatarFallback>
          </Avatar>

          <div className="flex-1 space-y-4">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <h1 className="text-3xl font-bold" data-testid="text-profile-name">
                  {name}
                </h1>
                <Badge variant="default" data-testid="badge-role">
                  {roleLabel}
                </Badge>
              </div>
              <p className="text-muted-foreground" data-testid="text-profile-info">
                {year} • {major}
              </p>
              <div className="flex items-center gap-2 mt-1 text-sm text-muted-foreground">
                <Mail className="h-4 w-4" />
                <span data-testid="text-profile-email">{email}</span>
              </div>
            </div>

            <p className="text-base leading-relaxed" data-testid="text-profile-bio">
              {bio}
            </p>

            <div className="flex flex-wrap gap-2">
              {interests.map((interest) => (
                <Badge key={interest} variant="secondary" data-testid={`badge-interest-${interest}`}>
                  {interest}
                </Badge>
              ))}
            </div>

            <div className="flex gap-2">
              <Button variant="outline" data-testid="button-edit-profile">
                <Settings className="h-4 w-4 mr-2" />
                Edit Profile
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
