import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";

interface SearchBarProps {
  placeholder?: string;
  value?: string;
  onChange?: (value: string) => void;
  onSearch?: (query: string) => void;
}

export function SearchBar({ 
  placeholder = "Search...", 
  value: controlledValue, 
  onChange, 
  onSearch,
  ...props
}: SearchBarProps & { "data-testid"?: string }) {
  const handleChange = (newValue: string) => {
    onChange?.(newValue);
    onSearch?.(newValue);
  };

  return (
    <div className="relative flex-1 max-w-md">
      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
      <Input
        type="search"
        placeholder={placeholder}
        value={controlledValue}
        onChange={(e) => handleChange(e.target.value)}
        className="pl-10"
        data-testid={props["data-testid"] || "input-search"}
      />
    </div>
  );
}
