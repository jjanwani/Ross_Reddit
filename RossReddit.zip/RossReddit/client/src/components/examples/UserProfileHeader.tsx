import { UserProfileHeader } from "../UserProfileHeader";
import avatar4 from "@assets/generated_images/Student_profile_avatar_4_bb25f0b0.png";

export default function UserProfileHeaderExample() {
  return (
    <UserProfileHeader
      name="Jordan Martinez"
      avatar={avatar4}
      email="jmartinez@umich.edu"
      year="Junior"
      major="Business Administration"
      interests={["Consulting", "Strategy", "Case Interviews", "Entrepreneurship"]}
      bio="Passionate about strategy consulting and helping underclassmen navigate recruiting. Currently interning at Bain & Company. Always happy to chat about case prep, networking, or anything Ross-related!"
      role="both"
    />
  );
}
