import { SearchBar } from "../SearchBar";

export default function SearchBarExample() {
  return (
    <div className="space-y-4">
      <SearchBar
        placeholder="Search posts, events, resources..."
        onSearch={(query) => console.log("Search:", query)}
      />
      <SearchBar
        placeholder="Find a mentor..."
        onSearch={(query) => console.log("Mentor search:", query)}
      />
    </div>
  );
}
