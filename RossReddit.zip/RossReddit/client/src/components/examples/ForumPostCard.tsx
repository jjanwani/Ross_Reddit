import { ForumPostCard } from "../ForumPostCard";

export default function ForumPostCardExample() {
  return (
    <div className="space-y-4">
      <ForumPostCard
        id="1"
        author={{
          name: "Sarah Chen",
          avatar: undefined,
          year: "Junior",
        }}
        title="Tips for McKinsey first round interviews?"
        content="I have my first round coming up next week and would love any advice on case prep. What resources did you find most helpful? Also, how technical do the cases tend to be?"
        tags={["consulting", "recruiting", "McKinsey"]}
        upvotes={24}
        commentCount={12}
        timestamp="2h ago"
      />
      <ForumPostCard
        id="2"
        author={{
          name: "Anonymous User",
          year: "Sophomore",
        }}
        title="Is it too late to start recruiting for finance internships?"
        content="I'm a sophomore and just realized I want to pivot to finance. Most of my classmates already have internships lined up. Should I focus on smaller firms or wait until junior year?"
        tags={["finance", "IB", "internships"]}
        upvotes={15}
        commentCount={8}
        timestamp="5h ago"
        isAnonymous={true}
      />
    </div>
  );
}
