import { MessageThread } from "../MessageThread";
import avatar1 from "@assets/generated_images/Student_profile_avatar_1_1a96ad59.png";

export default function MessageThreadExample() {
  const messages = [
    {
      id: "1",
      sender: { name: "Michael Chen", avatar: avatar1, isCurrentUser: false },
      content: "Hi! I saw you're interested in consulting. I'd be happy to help with case prep.",
      timestamp: "10:30 AM",
    },
    {
      id: "2",
      sender: { name: "You", isCurrentUser: true },
      content: "That would be amazing! I have my first round with Bain coming up next week.",
      timestamp: "10:32 AM",
    },
    {
      id: "3",
      sender: { name: "Michael Chen", avatar: avatar1, isCurrentUser: false },
      content: "Great! Let's schedule a time to practice. Are you free this Thursday afternoon?",
      timestamp: "10:35 AM",
    },
    {
      id: "4",
      sender: { name: "You", isCurrentUser: true },
      content: "Thursday at 3 PM works perfectly for me!",
      timestamp: "10:36 AM",
    },
  ];

  return (
    <MessageThread
      messages={messages}
      recipientName="Michael Chen"
      recipientAvatar={avatar1}
    />
  );
}
