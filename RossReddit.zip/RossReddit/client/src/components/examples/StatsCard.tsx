import { StatsCard } from "../StatsCard";
import { Users, MessageSquare, Calendar, BookOpen } from "lucide-react";

export default function StatsCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <StatsCard
        title="Active Matches"
        value={12}
        icon={Users}
        trend={{ value: "+3 this month", isPositive: true }}
      />
      <StatsCard
        title="Questions Answered"
        value={28}
        icon={MessageSquare}
        trend={{ value: "+8 this week", isPositive: true }}
      />
      <StatsCard
        title="Events Attended"
        value={6}
        icon={Calendar}
        trend={{ value: "2 upcoming", isPositive: true }}
      />
      <StatsCard
        title="Resources Saved"
        value={15}
        icon={BookOpen}
      />
    </div>
  );
}
