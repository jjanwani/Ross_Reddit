import { EventCard } from "../EventCard";

export default function EventCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      <EventCard
        id="1"
        title="Goldman Sachs Info Session"
        description="Learn about summer analyst opportunities in investment banking. Pizza will be provided!"
        date={new Date(2025, 9, 28, 18, 0)}
        location="Ross School R2320"
        category="Recruiting"
        attendeeCount={45}
        organizer="Finance Club"
      />
      <EventCard
        id="2"
        title="Coffee Chat: Tech Career Paths"
        description="Casual networking with Ross alumni working at Microsoft, Google, and Amazon."
        date={new Date(2025, 9, 30, 16, 0)}
        location="Starbucks on State St"
        category="Networking"
        attendeeCount={12}
        organizer="Tech Club"
      />
      <EventCard
        id="3"
        title="Case Interview Workshop"
        description="Practice market sizing and profitability cases with upperclassmen mentors."
        date={new Date(2025, 10, 2, 19, 0)}
        location="Ross School R1240"
        category="Academic"
        attendeeCount={28}
        organizer="Consulting Club"
      />
    </div>
  );
}
