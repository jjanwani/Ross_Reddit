import { ResourceCard } from "../ResourceCard";

export default function ResourceCardExample() {
  return (
    <div className="space-y-4">
      <ResourceCard
        id="1"
        title="Complete Guide to Consulting Case Interviews"
        description="Comprehensive PDF covering frameworks, practice cases, and tips from students who landed offers at MBB firms."
        category="Consulting"
        uploader="Alex Johnson"
        upvotes={156}
        downloadCount={342}
        lastUpdated="2 weeks ago"
      />
      <ResourceCard
        id="2"
        title="Investment Banking Interview Prep"
        description="Technical questions, accounting concepts, and valuation methods commonly asked in IB interviews."
        category="Finance"
        uploader="Emily Rodriguez"
        upvotes={98}
        downloadCount={215}
        lastUpdated="1 month ago"
      />
      <ResourceCard
        id="3"
        title="Leetcode Patterns for PM Tech Interviews"
        description="Common coding patterns and data structures for product management technical screens."
        category="Tech"
        uploader="David Kim"
        upvotes={72}
        downloadCount={128}
        lastUpdated="3 days ago"
      />
    </div>
  );
}
