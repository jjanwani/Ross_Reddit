import { MentorProfileCard } from "../MentorProfileCard";
import avatar1 from "@assets/generated_images/Student_profile_avatar_1_1a96ad59.png";
import avatar2 from "@assets/generated_images/Student_profile_avatar_2_c859d795.png";
import avatar3 from "@assets/generated_images/Student_profile_avatar_3_888edc3d.png";

export default function MentorProfileCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      <MentorProfileCard
        id="1"
        name="Michael Chen"
        avatar={avatar1}
        year="Senior"
        major="Business Administration"
        interests={["Consulting", "Strategy", "Case Prep"]}
        bio="Interned at McKinsey last summer. Happy to help with case interview prep and firm selection."
        matchScore={92}
      />
      <MentorProfileCard
        id="2"
        name="Jessica Williams"
        avatar={avatar2}
        year="Junior"
        major="Finance"
        interests={["Investment Banking", "Finance", "Recruiting"]}
        bio="Landed BB IB internship. Can share resume tips and technical interview prep strategies."
        matchScore={88}
      />
      <MentorProfileCard
        id="3"
        name="Ryan Patel"
        avatar={avatar3}
        year="Senior"
        major="Computer Science & Business"
        interests={["Tech", "Product Management", "Startups"]}
        bio="Worked at Google and a Series B startup. Love talking about PM recruiting and tech careers."
        matchScore={85}
      />
    </div>
  );
}
