import { FilterChips } from "../FilterChips";

export default function FilterChipsExample() {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-sm font-medium mb-3">Forum Filters</h3>
        <FilterChips
          availableFilters={["Consulting", "Finance", "Tech", "Internships", "Recruiting"]}
          onFilterChange={(filters) => console.log("Forum filters:", filters)}
        />
      </div>
      <div>
        <h3 className="text-sm font-medium mb-3">Event Filters</h3>
        <FilterChips
          availableFilters={["Recruiting", "Networking", "Academic", "Social"]}
          onFilterChange={(filters) => console.log("Event filters:", filters)}
        />
      </div>
    </div>
  );
}
