import { FileText, Download, ArrowUp, Bookmark } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { formatDistanceToNow } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import type { Resource } from "@shared/schema";

type ResourceCardProps = Resource;

const categoryVariants: Record<string, "default" | "secondary" | "outline" | "destructive"> = {
  Consulting: "default",
  Tech: "secondary",
  Finance: "default",
  Entrepreneurship: "secondary",
  Classes: "default",
  Recruitment: "secondary",
  Clubs: "default",
};

export function ResourceCard({
  id,
  title,
  description,
  category,
  uploaderId,
  upvotes: initialUpvotes,
  downloadCount: initialDownloadCount,
  createdAt,
}: ResourceCardProps) {
  const [upvotes, setUpvotes] = useState(parseInt(initialUpvotes, 10));
  const [downloadCount, setDownloadCount] = useState(parseInt(initialDownloadCount, 10));
  const [isUpvoted, setIsUpvoted] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const { toast } = useToast();

  const upvoteMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", `/api/resources/${id}/upvote`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/resources"] });
    },
    onError: () => {
      setUpvotes((prev) => Math.max(0, prev - 1));
      setIsUpvoted(false);
      toast({
        title: "Error",
        description: "Failed to upvote resource",
        variant: "destructive",
      });
    },
  });

  const downloadMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch(`/api/resources/${id}/download-url`, {
        credentials: "include",
      });
      if (!response.ok) {
        throw new Error("Failed to get download URL");
      }
      const { downloadUrl } = await response.json();
      await apiRequest("POST", `/api/resources/${id}/download`);
      return downloadUrl;
    },
    onSuccess: (downloadUrl: string) => {
      queryClient.invalidateQueries({ queryKey: ["/api/resources"] });
      window.open(downloadUrl, "_blank");
    },
    onError: () => {
      setDownloadCount((prev) => Math.max(0, prev - 1));
      toast({
        title: "Error",
        description: "Failed to download resource",
        variant: "destructive",
      });
    },
  });

  const handleUpvote = () => {
    if (!isUpvoted) {
      setUpvotes(upvotes + 1);
      setIsUpvoted(true);
      upvoteMutation.mutate();
    }
  };

  const handleDownload = () => {
    setDownloadCount(downloadCount + 1);
    downloadMutation.mutate();
  };

  const lastUpdated = formatDistanceToNow(new Date(createdAt), { addSuffix: true });

  return (
    <Card className="p-6">
      <div className="flex items-start gap-4">
        <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-muted">
          <FileText className="h-6 w-6 text-muted-foreground" />
        </div>
        <div className="flex-1 space-y-3">
          <div>
            <div className="flex items-start justify-between gap-2 mb-2">
              <Badge 
                variant={categoryVariants[category] || "outline"} 
                className="text-xs" 
                data-testid="badge-category"
              >
                {category}
              </Badge>
            </div>
            <h3 className="text-lg font-semibold mb-1" data-testid="text-resource-title">
              {title}
            </h3>
            <p className="text-sm text-muted-foreground leading-relaxed" data-testid="text-resource-description">
              {description}
            </p>
          </div>

          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            <span data-testid="text-uploader">By User {uploaderId.slice(0, 8)}</span>
            <span>•</span>
            <span data-testid="text-download-count">{downloadCount} downloads</span>
            <span>•</span>
            <span data-testid="text-last-updated">Updated {lastUpdated}</span>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant={isUpvoted ? "default" : "ghost"}
              size="sm"
              onClick={handleUpvote}
              disabled={isUpvoted || upvoteMutation.isPending}
              data-testid="button-upvote"
            >
              <ArrowUp className="h-4 w-4 mr-1" />
              <span>{upvotes}</span>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsSaved(!isSaved)}
              data-testid="button-favorite"
            >
              <Bookmark className={`h-4 w-4 mr-1 ${isSaved ? "fill-current" : ""}`} />
              <span>{isSaved ? "Saved" : "Save"}</span>
            </Button>
            <Button 
              variant="default" 
              size="sm" 
              className="ml-auto" 
              onClick={handleDownload}
              disabled={downloadMutation.isPending}
              data-testid="button-download"
            >
              <Download className="h-4 w-4 mr-1" />
              <span>Download</span>
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
}
