import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { X } from "lucide-react";
import { useState } from "react";

const popularTags = ["consulting", "finance", "tech", "recruiting", "internships", "IB", "clubs"];

export function PostQuestionModal({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [customTag, setCustomTag] = useState("");

  const addTag = (tag: string) => {
    if (!selectedTags.includes(tag) && selectedTags.length < 5) {
      setSelectedTags([...selectedTags, tag]);
    }
  };

  const removeTag = (tag: string) => {
    setSelectedTags(selectedTags.filter((t) => t !== tag));
  };

  const addCustomTag = () => {
    if (customTag && !selectedTags.includes(customTag) && selectedTags.length < 5) {
      setSelectedTags([...selectedTags, customTag.toLowerCase()]);
      setCustomTag("");
    }
  };

  const handleSubmit = () => {
    console.log("Posting question:", { title, content, isAnonymous, tags: selectedTags });
    setOpen(false);
    setTitle("");
    setContent("");
    setIsAnonymous(false);
    setSelectedTags([]);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Post a Question</DialogTitle>
          <DialogDescription>
            Ask the Ross community about courses, recruiting, or opportunities.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Question Title</Label>
            <Input
              id="title"
              placeholder="What would you like to know?"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              data-testid="input-question-title"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="content">Details</Label>
            <Textarea
              id="content"
              placeholder="Provide more context for your question..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="min-h-32"
              data-testid="input-question-content"
            />
          </div>

          <div className="space-y-2">
            <Label>Tags (up to 5)</Label>
            <div className="flex flex-wrap gap-2 mb-2">
              {selectedTags.map((tag) => (
                <Badge key={tag} variant="default" data-testid={`selected-tag-${tag}`}>
                  #{tag}
                  <button onClick={() => removeTag(tag)} className="ml-1">
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              ))}
            </div>
            <div className="flex flex-wrap gap-2 mb-2">
              {popularTags
                .filter((tag) => !selectedTags.includes(tag))
                .map((tag) => (
                  <Badge
                    key={tag}
                    variant="outline"
                    className="cursor-pointer hover-elevate"
                    onClick={() => addTag(tag)}
                    data-testid={`tag-option-${tag}`}
                  >
                    #{tag}
                  </Badge>
                ))}
            </div>
            <div className="flex gap-2">
              <Input
                placeholder="Add custom tag..."
                value={customTag}
                onChange={(e) => setCustomTag(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && addCustomTag()}
                data-testid="input-custom-tag"
              />
              <Button onClick={addCustomTag} variant="outline" data-testid="button-add-tag">
                Add
              </Button>
            </div>
          </div>

          <div className="flex items-center justify-between p-4 rounded-lg border">
            <div className="space-y-1">
              <Label htmlFor="anonymous" className="cursor-pointer">
                Post Anonymously
              </Label>
              <p className="text-sm text-muted-foreground">
                Your name won't be shown to other users
              </p>
            </div>
            <Switch
              id="anonymous"
              checked={isAnonymous}
              onCheckedChange={setIsAnonymous}
              data-testid="switch-anonymous"
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)} data-testid="button-cancel">
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={!title || !content} data-testid="button-submit">
            Post Question
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
