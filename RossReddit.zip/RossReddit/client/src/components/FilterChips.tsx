import { Badge } from "@/components/ui/badge";

interface FilterChipsProps {
  availableFilters: string[];
  selectedFilter?: string;
  onFilterChange?: (selected: string) => void;
}

export function FilterChips({ 
  availableFilters, 
  selectedFilter = "All",
  onFilterChange 
}: FilterChipsProps) {
  const handleFilterClick = (filter: string) => {
    onFilterChange?.(filter);
  };

  return (
    <div className="flex flex-wrap items-center gap-2">
      <span className="text-sm font-medium text-muted-foreground">Filter:</span>
      {availableFilters.map((filter) => {
        const isSelected = selectedFilter === filter;
        return (
          <Badge
            key={filter}
            variant={isSelected ? "default" : "outline"}
            className="cursor-pointer hover-elevate active-elevate-2 text-xs"
            onClick={() => handleFilterClick(filter)}
            data-testid={`filter-${filter.toLowerCase()}`}
          >
            {filter}
          </Badge>
        );
      })}
    </div>
  );
}
