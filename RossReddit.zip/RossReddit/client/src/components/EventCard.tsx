import { Calendar, MapPin, Users } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import { format } from "date-fns";

interface EventCardProps {
  id: string;
  title: string;
  description: string;
  date: Date;
  location: string;
  category: "Recruiting" | "Networking" | "Academic" | "Social";
  attendeeCount: number;
  organizer: string;
}

const categoryColors = {
  Recruiting: "border-l-primary",
  Networking: "border-l-chart-2",
  Academic: "border-l-chart-3",
  Social: "border-l-chart-4",
};

export function EventCard({
  title,
  description,
  date,
  location,
  category,
  attendeeCount,
  organizer,
}: EventCardProps) {
  const [isRSVPed, setIsRSVPed] = useState(false);

  return (
    <Card className={`p-6 border-l-4 ${categoryColors[category]}`}>
      <div className="space-y-4">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <Badge variant="secondary" className="text-xs" data-testid="badge-category">
                {category}
              </Badge>
            </div>
            <h3 className="text-lg font-semibold mb-2" data-testid="text-event-title">
              {title}
            </h3>
            <p className="text-sm text-muted-foreground leading-relaxed" data-testid="text-event-description">
              {description}
            </p>
          </div>
        </div>

        <div className="space-y-2 text-sm">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Calendar className="h-4 w-4" />
            <span data-testid="text-event-date">
              {format(date, "EEEE, MMMM d, yyyy 'at' h:mm a")}
            </span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <MapPin className="h-4 w-4" />
            <span data-testid="text-event-location">{location}</span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Users className="h-4 w-4" />
            <span data-testid="text-attendee-count">
              {attendeeCount} attending • Hosted by {organizer}
            </span>
          </div>
        </div>

        <Button
          variant={isRSVPed ? "secondary" : "default"}
          className="w-full"
          onClick={() => setIsRSVPed(!isRSVPed)}
          data-testid="button-rsvp"
        >
          {isRSVPed ? "RSVP'd ✓" : "RSVP"}
        </Button>
      </div>
    </Card>
  );
}
