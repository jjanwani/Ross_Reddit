import { ArrowUp, MessageSquare, Bookmark, MoreHorizontal } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";

interface ForumPostCardProps {
  id: string;
  author: {
    name: string;
    avatar?: string;
    year: string;
  };
  title: string;
  content: string;
  tags: string[];
  upvotes: number;
  commentCount: number;
  timestamp: string;
  isAnonymous?: boolean;
}

export function ForumPostCard({
  author,
  title,
  content,
  tags,
  upvotes: initialUpvotes,
  commentCount,
  timestamp,
  isAnonymous = false,
}: ForumPostCardProps) {
  const [upvotes, setUpvotes] = useState(initialUpvotes);
  const [isUpvoted, setIsUpvoted] = useState(false);
  const [isSaved, setIsSaved] = useState(false);

  const handleUpvote = () => {
    if (isUpvoted) {
      setUpvotes(upvotes - 1);
      setIsUpvoted(false);
    } else {
      setUpvotes(upvotes + 1);
      setIsUpvoted(true);
    }
  };

  const displayName = isAnonymous ? "Anonymous" : author.name;
  const displayAvatar = isAnonymous ? undefined : author.avatar;
  const initials = displayName
    .split(" ")
    .map((n) => n[0])
    .join("");

  return (
    <Card className="p-6">
      <div className="flex items-start gap-4">
        <div className="flex flex-col items-center gap-1">
          <Button
            variant={isUpvoted ? "default" : "ghost"}
            size="icon"
            className="h-8 w-8"
            onClick={handleUpvote}
            data-testid="button-upvote"
          >
            <ArrowUp className="h-4 w-4" />
          </Button>
          <span className="text-sm font-semibold" data-testid="text-upvote-count">
            {upvotes}
          </span>
        </div>

        <div className="flex-1 space-y-3">
          <div className="flex items-center gap-2">
            <Avatar className="h-8 w-8">
              <AvatarImage src={displayAvatar} />
              <AvatarFallback>{initials}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <p className="text-sm font-medium" data-testid="text-author-name">
                {displayName}
              </p>
              <p className="text-xs text-muted-foreground" data-testid="text-timestamp">
                {!isAnonymous && `${author.year} • `}
                {timestamp}
              </p>
            </div>
            <Button variant="ghost" size="icon" className="h-8 w-8" data-testid="button-more">
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-2" data-testid="text-post-title">
              {title}
            </h3>
            <p className="text-base leading-relaxed text-foreground" data-testid="text-post-content">
              {content}
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            {tags.map((tag) => (
              <Badge
                key={tag}
                variant="secondary"
                className="text-xs uppercase"
                data-testid={`badge-tag-${tag}`}
              >
                #{tag}
              </Badge>
            ))}
          </div>

          <div className="flex items-center gap-4 pt-2">
            <Button variant="ghost" size="sm" data-testid="button-comment">
              <MessageSquare className="h-4 w-4 mr-2" />
              <span>{commentCount} comments</span>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsSaved(!isSaved)}
              data-testid="button-save"
            >
              <Bookmark className={`h-4 w-4 mr-2 ${isSaved ? "fill-current" : ""}`} />
              <span>{isSaved ? "Saved" : "Save"}</span>
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
}
