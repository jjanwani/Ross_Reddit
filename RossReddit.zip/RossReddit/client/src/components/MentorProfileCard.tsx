import { MessageSquare } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface MentorProfileCardProps {
  id: string;
  name: string;
  avatar?: string;
  year: string;
  major: string;
  interests: string[];
  bio: string;
  matchScore?: number;
}

export function MentorProfileCard({
  name,
  avatar,
  year,
  major,
  interests,
  bio,
  matchScore,
}: MentorProfileCardProps) {
  const initials = name
    .split(" ")
    .map((n) => n[0])
    .join("");

  return (
    <Card className="p-6 hover-elevate">
      <div className="flex flex-col items-center text-center space-y-4">
        <Avatar className="h-24 w-24">
          <AvatarImage src={avatar} />
          <AvatarFallback className="text-2xl">{initials}</AvatarFallback>
        </Avatar>

        <div className="space-y-1">
          <h3 className="text-lg font-semibold" data-testid="text-mentor-name">
            {name}
          </h3>
          <p className="text-sm text-muted-foreground" data-testid="text-mentor-info">
            {year} • {major}
          </p>
          {matchScore && (
            <Badge variant="default" className="text-xs" data-testid="badge-match-score">
              {matchScore}% Match
            </Badge>
          )}
        </div>

        <div className="flex flex-wrap justify-center gap-2">
          {interests.map((interest) => (
            <Badge
              key={interest}
              variant="secondary"
              className="text-xs"
              data-testid={`badge-interest-${interest}`}
            >
              {interest}
            </Badge>
          ))}
        </div>

        <p className="text-sm text-muted-foreground leading-relaxed" data-testid="text-mentor-bio">
          {bio}
        </p>

        <Button className="w-full" data-testid="button-connect">
          <MessageSquare className="h-4 w-4 mr-2" />
          Connect
        </Button>
      </div>
    </Card>
  );
}
