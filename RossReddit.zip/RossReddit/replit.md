# Ross Reddit - University of Michigan Ross Community Platform

## Overview

Ross Reddit is a closed community web application for University of Michigan Ross School of Business students. It aims to centralize mentorship, recruiting advice, and event information, addressing the fragmentation of resources and inequitable access to mentorship. Key capabilities include a mentorship matching system, a Q&A forum, an event calendar, and a searchable resource repository. The platform connects underclassmen with upperclassmen and provides a dedicated space for direct messaging.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

The frontend is built with React and TypeScript, using Vite for development. Routing is handled by Wouter, and the UI is constructed using Radix UI primitives with shadcn/ui styling (new-york variant), following a mobile-first, responsive design inspired by Material Design. Styling is managed with Tailwind CSS, supporting light/dark themes. TanStack Query is used for server state management, and API requests are handled by a centralized utility. The component structure is modular, emphasizing reusability and consistent naming.

### Backend Architecture

The backend utilizes Express.js with Node.js and TypeScript. It exposes a RESTful API with modular routes. An abstract storage interface allows for switching between an in-memory development store and a PostgreSQL database. Session management is prepared for `connect-pg-simple` with PostgreSQL. Vite middleware mode is integrated for Hot Module Replacement during development.

### Data Storage Architecture

The application uses PostgreSQL accessed via Neon serverless driver and Drizzle ORM for type-safe operations. Schema migrations are managed with `drizzle-kit`. Key tables include Users, Events, ForumPosts, ForumResponses, UserProfiles, and Messages. Zod schemas generated from Drizzle definitions provide runtime validation. The storage abstraction allows flexible data source switching.

### Authentication and Authorization

Authentication is planned to be email-based, restricted to `umich.edu` addresses. Session management will use Express session middleware with a PostgreSQL store. A role-based authorization model will support Mentees, Mentors, and Moderators, with users potentially holding multiple roles.

### UI/UX Decisions

The design prioritizes clarity, scannable content, and a professional aesthetic appropriate for a university platform. It features a consistent design system, light/dark theme support, and a mobile-first approach to ensure responsiveness across devices.

### Technical Implementations

- **Monorepo Structure:** Client and server code coexist, sharing TypeScript types for full-stack type safety.
- **Vite Middleware Mode:** Integrates Vite with Express for simplified local development.
- **Storage Abstraction:** Decouples business logic from storage implementation.
- **Component Modularity:** Utilizes composition with Radix UI for flexible and consistent UI.
- **Mobile-First Design:** Responsive layouts adapt from single-column mobile to multi-column desktop.
- **Theme System:** CSS variable-based theming with light/dark mode and localStorage persistence.

### Feature Specifications

- **Events:** Comprehensive event schema with multi-dimensional filtering (center, recruiting focus, program, event type, location). API supports filtered retrieval. UI provides a four-dimensional filtering interface, event cards, and external registration links.
- **Forum:** Q&A forum with posts and responses. Supports anonymous posting, custom hashtags, upvoting, and search. UI includes a question list, an "Ask Question" dialog, and post detail pages with threaded responses.
- **Resources:** System for uploading and sharing files with categorization (Classes, Recruitment, Clubs, etc.). Integrates with Replit Object Storage for secure file hosting. API supports filtering, searching, upvoting, and download tracking. UI features an upload dialog, category filtering, search, and resource cards with file metadata.

## External Dependencies

### UI Component Libraries

- **Radix UI:** Unstyled, accessible UI primitives.
- **shadcn/ui:** Styling patterns for Radix UI.
- **Lucide React:** Icon library.

### Database and ORM

- **Neon PostgreSQL:** Serverless PostgreSQL database.
- **Drizzle ORM:** Type-safe ORM for PostgreSQL.
- **drizzle-kit:** CLI for schema migrations.

### Form Handling and Validation

- **React Hook Form:** Performant form library.
- **Zod:** TypeScript-first schema validation.

### State Management

- **TanStack Query (React Query):** Server state management.

### Styling and Design

- **Tailwind CSS:** Utility-first CSS framework.
- **class-variance-authority:** Type-safe variant management.
- **clsx & tailwind-merge:** Utilities for conditional class names.

### Date and Time

- **date-fns:** Date utility library.

### Development Tools

- **Vite:** Fast development server and build tool.
- **TypeScript:** Static type checking.
- **esbuild:** Fast JavaScript bundler.

### Routing

- **Wouter:** Minimalist client-side router.

### Session Management (Planned)

- **connect-pg-simple:** PostgreSQL session store for Express.