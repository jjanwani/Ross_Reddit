import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMessageSchema, insertForumPostSchema, insertForumResponseSchema, insertResourceSchema } from "@shared/schema";
import { ObjectStorageService, ObjectNotFoundError } from "./objectStorage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Events API
  app.get("/api/events", async (req, res) => {
    try {
      const { center, recruitingFocus, program, eventType } = req.query;
      
      const filters = {
        center: center as string | undefined,
        recruitingFocus: recruitingFocus as string | undefined,
        program: program as string | undefined,
        eventType: eventType as string | undefined,
      };
      
      const events = await storage.getEvents(filters);
      res.json(events);
    } catch (error) {
      console.error("Error fetching events:", error);
      res.status(500).json({ error: "Failed to fetch events" });
    }
  });

  app.get("/api/events/:id", async (req, res) => {
    try {
      const event = await storage.getEvent(req.params.id);
      
      if (!event) {
        return res.status(404).json({ error: "Event not found" });
      }
      
      res.json(event);
    } catch (error) {
      console.error("Error fetching event:", error);
      res.status(500).json({ error: "Failed to fetch event" });
    }
  });

  // User Profiles API
  app.get("/api/profiles", async (req, res) => {
    try {
      const { rossCenter, careerInterests, program } = req.query;
      
      const filters = {
        rossCenter: rossCenter as string | undefined,
        careerInterests: careerInterests ? (Array.isArray(careerInterests) ? careerInterests as string[] : [careerInterests as string]) : undefined,
        program: program as string | undefined,
      };
      
      const profiles = await storage.getUserProfiles(filters);
      res.json(profiles);
    } catch (error) {
      console.error("Error fetching profiles:", error);
      res.status(500).json({ error: "Failed to fetch profiles" });
    }
  });

  app.get("/api/profiles/:userId", async (req, res) => {
    try {
      const profile = await storage.getUserProfile(req.params.userId);
      
      if (!profile) {
        return res.status(404).json({ error: "Profile not found" });
      }
      
      res.json(profile);
    } catch (error) {
      console.error("Error fetching profile:", error);
      res.status(500).json({ error: "Failed to fetch profile" });
    }
  });

  // Messages API
  app.get("/api/messages", async (req, res) => {
    try {
      const { userId } = req.query;
      
      if (!userId) {
        return res.status(400).json({ error: "userId is required" });
      }
      
      const messages = await storage.getMessages(userId as string);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ error: "Failed to fetch messages" });
    }
  });

  app.get("/api/conversations/:userId/:otherUserId", async (req, res) => {
    try {
      const { userId, otherUserId } = req.params;
      const conversation = await storage.getConversation(userId, otherUserId);
      res.json(conversation);
    } catch (error) {
      console.error("Error fetching conversation:", error);
      res.status(500).json({ error: "Failed to fetch conversation" });
    }
  });

  app.post("/api/messages", async (req, res) => {
    try {
      const validatedData = insertMessageSchema.parse(req.body);
      const message = await storage.createMessage(validatedData);
      res.status(201).json(message);
    } catch (error) {
      console.error("Error creating message:", error);
      if (error instanceof Error && error.name === "ZodError") {
        return res.status(400).json({ error: "Invalid message data" });
      }
      res.status(500).json({ error: "Failed to create message" });
    }
  });

  app.patch("/api/messages/:id/read", async (req, res) => {
    try {
      await storage.markMessageAsRead(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error marking message as read:", error);
      res.status(500).json({ error: "Failed to mark message as read" });
    }
  });

  // Forum Posts API
  app.get("/api/forum/posts", async (req, res) => {
    try {
      const { search } = req.query;
      const posts = await storage.getForumPosts(search as string | undefined);
      res.json(posts);
    } catch (error) {
      console.error("Error fetching forum posts:", error);
      res.status(500).json({ error: "Failed to fetch forum posts" });
    }
  });

  app.get("/api/forum/posts/:id", async (req, res) => {
    try {
      const post = await storage.getForumPost(req.params.id);
      
      if (!post) {
        return res.status(404).json({ error: "Forum post not found" });
      }
      
      res.json(post);
    } catch (error) {
      console.error("Error fetching forum post:", error);
      res.status(500).json({ error: "Failed to fetch forum post" });
    }
  });

  app.post("/api/forum/posts", async (req, res) => {
    try {
      const validatedData = insertForumPostSchema.parse(req.body);
      const post = await storage.createForumPost(validatedData);
      res.status(201).json(post);
    } catch (error) {
      console.error("Error creating forum post:", error);
      if (error instanceof Error && error.name === "ZodError") {
        return res.status(400).json({ error: "Invalid forum post data" });
      }
      res.status(500).json({ error: "Failed to create forum post" });
    }
  });

  app.post("/api/forum/posts/:id/upvote", async (req, res) => {
    try {
      await storage.upvoteForumPost(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error upvoting forum post:", error);
      res.status(500).json({ error: "Failed to upvote forum post" });
    }
  });

  // Forum Responses API
  app.get("/api/forum/posts/:postId/responses", async (req, res) => {
    try {
      const responses = await storage.getForumResponses(req.params.postId);
      res.json(responses);
    } catch (error) {
      console.error("Error fetching forum responses:", error);
      res.status(500).json({ error: "Failed to fetch forum responses" });
    }
  });

  app.post("/api/forum/posts/:postId/responses", async (req, res) => {
    try {
      const validatedData = insertForumResponseSchema.parse(req.body);
      const response = await storage.createForumResponse(validatedData);
      res.status(201).json(response);
    } catch (error) {
      console.error("Error creating forum response:", error);
      if (error instanceof Error && error.name === "ZodError") {
        return res.status(400).json({ error: "Invalid forum response data" });
      }
      res.status(500).json({ error: "Failed to create forum response" });
    }
  });

  // Resources API
  app.get("/api/resources", async (req, res) => {
    try {
      const { category, search } = req.query;
      const filters = {
        category: category as string | undefined,
        searchQuery: search as string | undefined,
      };
      const resources = await storage.getResources(filters);
      res.json(resources);
    } catch (error) {
      console.error("Error fetching resources:", error);
      res.status(500).json({ error: "Failed to fetch resources" });
    }
  });

  app.get("/api/resources/:id", async (req, res) => {
    try {
      const resource = await storage.getResource(req.params.id);
      
      if (!resource) {
        return res.status(404).json({ error: "Resource not found" });
      }
      
      res.json(resource);
    } catch (error) {
      console.error("Error fetching resource:", error);
      res.status(500).json({ error: "Failed to fetch resource" });
    }
  });

  app.post("/api/resources", async (req, res) => {
    try {
      const validatedData = insertResourceSchema.parse(req.body);
      const resource = await storage.createResource(validatedData);
      res.status(201).json(resource);
    } catch (error) {
      console.error("Error creating resource:", error);
      if (error instanceof Error && error.name === "ZodError") {
        return res.status(400).json({ error: "Invalid resource data" });
      }
      res.status(500).json({ error: "Failed to create resource" });
    }
  });

  app.post("/api/resources/:id/upvote", async (req, res) => {
    try {
      await storage.upvoteResource(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error upvoting resource:", error);
      res.status(500).json({ error: "Failed to upvote resource" });
    }
  });

  app.post("/api/resources/:id/download", async (req, res) => {
    try {
      await storage.incrementDownloadCount(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error incrementing download count:", error);
      res.status(500).json({ error: "Failed to increment download count" });
    }
  });

  // Object Storage API
  const objectStorageService = new ObjectStorageService();

  app.post("/api/upload-url", async (req, res) => {
    try {
      const uploadUrl = await objectStorageService.getObjectEntityUploadURL();
      res.json({ url: uploadUrl });
    } catch (error) {
      console.error("Error generating upload URL:", error);
      res.status(500).json({ error: "Failed to generate upload URL" });
    }
  });

  app.get("/api/resources/:id/download-url", async (req, res) => {
    try {
      const resource = await storage.getResource(req.params.id);
      
      if (!resource) {
        return res.status(404).json({ error: "Resource not found" });
      }
      
      res.json({ downloadUrl: `/objects${resource.filePath.replace('/objects', '')}` });
    } catch (error) {
      console.error("Error getting download URL:", error);
      res.status(500).json({ error: "Failed to get download URL" });
    }
  });

  app.get("/objects/*", async (req, res) => {
    try {
      const objectPath = "/" + req.params[0];
      const objectFile = await objectStorageService.getObjectEntityFile(objectPath);
      await objectStorageService.downloadObject(objectFile, res);
    } catch (error) {
      if (error instanceof ObjectNotFoundError) {
        return res.status(404).json({ error: "Object not found" });
      }
      console.error("Error downloading object:", error);
      res.status(500).json({ error: "Failed to download object" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
