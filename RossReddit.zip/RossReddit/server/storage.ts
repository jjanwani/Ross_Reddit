import { 
  type User, 
  type InsertUser, 
  type Event, 
  type InsertEvent,
  type UserProfile,
  type InsertUserProfile,
  type Message,
  type InsertMessage,
  type ForumPost,
  type InsertForumPost,
  type ForumResponse,
  type InsertForumResponse,
  type Resource,
  type InsertResource,
} from "@shared/schema";
import { randomUUID } from "crypto";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getEvents(filters?: {
    center?: string;
    recruitingFocus?: string;
    program?: string;
    eventType?: string;
  }): Promise<Event[]>;
  getEvent(id: string): Promise<Event | undefined>;
  createEvent(event: InsertEvent): Promise<Event>;

  getUserProfile(userId: string): Promise<UserProfile | undefined>;
  getUserProfiles(filters?: {
    rossCenter?: string;
    careerInterests?: string[];
    program?: string;
  }): Promise<UserProfile[]>;
  createUserProfile(profile: InsertUserProfile): Promise<UserProfile>;

  getMessages(userId: string): Promise<Message[]>;
  getConversation(userId: string, otherUserId: string): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  markMessageAsRead(messageId: string): Promise<void>;

  getForumPosts(searchQuery?: string): Promise<ForumPost[]>;
  getForumPost(id: string): Promise<ForumPost | undefined>;
  createForumPost(post: InsertForumPost): Promise<ForumPost>;
  upvoteForumPost(postId: string): Promise<void>;

  getForumResponses(postId: string): Promise<ForumResponse[]>;
  createForumResponse(response: InsertForumResponse): Promise<ForumResponse>;

  getResources(filters?: {
    category?: string;
    searchQuery?: string;
  }): Promise<Resource[]>;
  getResource(id: string): Promise<Resource | undefined>;
  createResource(resource: InsertResource): Promise<Resource>;
  upvoteResource(resourceId: string): Promise<void>;
  incrementDownloadCount(resourceId: string): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private events: Map<string, Event>;
  private userProfiles: Map<string, UserProfile>;
  private messages: Map<string, Message>;
  private forumPosts: Map<string, ForumPost>;
  private forumResponses: Map<string, ForumResponse>;
  private resources: Map<string, Resource>;

  constructor() {
    this.users = new Map();
    this.events = new Map();
    this.forumPosts = new Map();
    this.forumResponses = new Map();
    this.userProfiles = new Map();
    this.messages = new Map();
    this.resources = new Map();
    this.seedEvents();
    this.seedUserProfiles();
    this.seedMessages();
    this.seedResources();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getEvents(filters?: {
    center?: string;
    recruitingFocus?: string;
    program?: string;
    eventType?: string;
  }): Promise<Event[]> {
    let eventsArray = Array.from(this.events.values());
    
    if (filters) {
      if (filters.center && filters.center !== "All") {
        eventsArray = eventsArray.filter(e => e.center === filters.center);
      }
      if (filters.recruitingFocus && filters.recruitingFocus !== "All") {
        eventsArray = eventsArray.filter(e => e.recruitingFocus === filters.recruitingFocus);
      }
      if (filters.program && filters.program !== "All") {
        eventsArray = eventsArray.filter(e => e.program === filters.program);
      }
      if (filters.eventType && filters.eventType !== "All") {
        eventsArray = eventsArray.filter(e => e.eventType === filters.eventType);
      }
    }
    
    return eventsArray.sort((a, b) => 
      new Date(a.startTime).getTime() - new Date(b.startTime).getTime()
    );
  }

  async getEvent(id: string): Promise<Event | undefined> {
    return this.events.get(id);
  }

  async createEvent(insertEvent: InsertEvent): Promise<Event> {
    const id = randomUUID();
    const event: Event = { 
      ...insertEvent, 
      id,
      endTime: insertEvent.endTime ?? null,
      center: insertEvent.center ?? null,
      recruitingFocus: insertEvent.recruitingFocus ?? null,
      program: insertEvent.program ?? null,
      tags: insertEvent.tags ?? null,
      imageUrl: insertEvent.imageUrl ?? null,
      registrationUrl: insertEvent.registrationUrl ?? null,
    };
    this.events.set(id, event);
    return event;
  }

  async getUserProfile(userId: string): Promise<UserProfile | undefined> {
    return Array.from(this.userProfiles.values()).find(
      (profile) => profile.userId === userId
    );
  }

  async getUserProfiles(filters?: {
    rossCenter?: string;
    careerInterests?: string[];
    program?: string;
  }): Promise<UserProfile[]> {
    let profiles = Array.from(this.userProfiles.values());

    if (filters) {
      if (filters.rossCenter) {
        profiles = profiles.filter(p => p.rossCenter === filters.rossCenter);
      }
      if (filters.careerInterests && filters.careerInterests.length > 0) {
        profiles = profiles.filter(p => 
          p.careerInterests.some(interest => 
            filters.careerInterests!.includes(interest)
          )
        );
      }
      if (filters.program) {
        profiles = profiles.filter(p => p.program === filters.program);
      }
    }

    return profiles;
  }

  async createUserProfile(insertProfile: InsertUserProfile): Promise<UserProfile> {
    const id = randomUUID();
    const profile: UserProfile = {
      ...insertProfile,
      id,
      rossCenter: insertProfile.rossCenter ?? null,
      bio: insertProfile.bio ?? null,
      avatarUrl: insertProfile.avatarUrl ?? null,
    };
    this.userProfiles.set(id, profile);
    return profile;
  }

  async getMessages(userId: string): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(m => m.senderId === userId || m.recipientId === userId)
      .sort((a, b) => new Date(b.sentAt).getTime() - new Date(a.sentAt).getTime());
  }

  async getConversation(userId: string, otherUserId: string): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(m => 
        (m.senderId === userId && m.recipientId === otherUserId) ||
        (m.senderId === otherUserId && m.recipientId === userId)
      )
      .sort((a, b) => new Date(a.sentAt).getTime() - new Date(b.sentAt).getTime());
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = randomUUID();
    const message: Message = {
      ...insertMessage,
      id,
      sentAt: new Date(),
      isRead: insertMessage.isRead ?? "false",
    };
    this.messages.set(id, message);
    return message;
  }

  async markMessageAsRead(messageId: string): Promise<void> {
    const message = this.messages.get(messageId);
    if (message) {
      message.isRead = "true";
      this.messages.set(messageId, message);
    }
  }

  async getForumPosts(searchQuery?: string): Promise<ForumPost[]> {
    let posts = Array.from(this.forumPosts.values());

    if (searchQuery && searchQuery.trim() !== "") {
      const query = searchQuery.toLowerCase().trim();
      posts = posts.filter((post) => {
        const titleMatch = post.title.toLowerCase().includes(query);
        const contentMatch = post.content.toLowerCase().includes(query);
        const hashtagMatch = post.hashtags.some((tag) =>
          tag.toLowerCase().includes(query)
        );
        return titleMatch || contentMatch || hashtagMatch;
      });
    }

    return posts.sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getForumPost(id: string): Promise<ForumPost | undefined> {
    return this.forumPosts.get(id);
  }

  async createForumPost(insertPost: InsertForumPost): Promise<ForumPost> {
    const id = randomUUID();
    const post: ForumPost = {
      ...insertPost,
      id,
      createdAt: new Date(),
      upvotes: insertPost.upvotes ?? "0",
      isAnonymous: insertPost.isAnonymous ?? "false",
    };
    this.forumPosts.set(id, post);
    return post;
  }

  async upvoteForumPost(postId: string): Promise<void> {
    const post = this.forumPosts.get(postId);
    if (post) {
      const currentUpvotes = parseInt(post.upvotes, 10);
      post.upvotes = String(currentUpvotes + 1);
      this.forumPosts.set(postId, post);
    }
  }

  async getForumResponses(postId: string): Promise<ForumResponse[]> {
    return Array.from(this.forumResponses.values())
      .filter((response) => response.postId === postId)
      .sort((a, b) => 
        new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
      );
  }

  async createForumResponse(insertResponse: InsertForumResponse): Promise<ForumResponse> {
    const id = randomUUID();
    const response: ForumResponse = {
      ...insertResponse,
      id,
      createdAt: new Date(),
      isAnonymous: insertResponse.isAnonymous ?? "false",
    };
    this.forumResponses.set(id, response);
    return response;
  }

  async getResources(filters?: {
    category?: string;
    searchQuery?: string;
  }): Promise<Resource[]> {
    let resourcesArray = Array.from(this.resources.values());

    if (filters) {
      if (filters.category && filters.category !== "All") {
        resourcesArray = resourcesArray.filter(r => r.category === filters.category);
      }
      if (filters.searchQuery && filters.searchQuery.trim() !== "") {
        const query = filters.searchQuery.toLowerCase().trim();
        resourcesArray = resourcesArray.filter((resource) => {
          const titleMatch = resource.title.toLowerCase().includes(query);
          const descriptionMatch = resource.description.toLowerCase().includes(query);
          const categoryMatch = resource.category.toLowerCase().includes(query);
          return titleMatch || descriptionMatch || categoryMatch;
        });
      }
    }

    return resourcesArray.sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getResource(id: string): Promise<Resource | undefined> {
    return this.resources.get(id);
  }

  async createResource(insertResource: InsertResource): Promise<Resource> {
    const id = randomUUID();
    const resource: Resource = {
      ...insertResource,
      id,
      createdAt: new Date(),
      upvotes: insertResource.upvotes ?? "0",
      downloadCount: insertResource.downloadCount ?? "0",
    };
    this.resources.set(id, resource);
    return resource;
  }

  async upvoteResource(resourceId: string): Promise<void> {
    const resource = this.resources.get(resourceId);
    if (resource) {
      const currentUpvotes = parseInt(resource.upvotes, 10);
      resource.upvotes = String(currentUpvotes + 1);
      this.resources.set(resourceId, resource);
    }
  }

  async incrementDownloadCount(resourceId: string): Promise<void> {
    const resource = this.resources.get(resourceId);
    if (resource) {
      const currentDownloads = parseInt(resource.downloadCount, 10);
      resource.downloadCount = String(currentDownloads + 1);
      this.resources.set(resourceId, resource);
    }
  }

  private seedEvents() {
    const sampleEvents: InsertEvent[] = [
      {
        title: "Tech Recruiting Workshop: Breaking into Product Management",
        description: "Join us for an interactive workshop where industry leaders from Google, Microsoft, and Amazon share insights on breaking into product management roles. Learn about resume tips, interview strategies, and networking best practices.",
        startTime: new Date("2025-10-28T18:00:00"),
        endTime: new Date("2025-10-28T20:00:00"),
        location: "Blau Auditorium",
        locationType: "On-campus",
        center: "Career Development",
        recruitingFocus: "Tech",
        program: "BBA",
        eventType: "Career Workshop",
        tags: ["Tech", "Product Management", "Recruiting"],
        registrationUrl: "https://impact.umich.edu/events/tech-recruiting-workshop",
      },
      {
        title: "Zell Entrepreneurship Pitch Competition Finals",
        description: "Watch Ross's best student entrepreneurs pitch their startups to a panel of venture capitalists and angel investors. Network with founders and investors during the reception.",
        startTime: new Date("2025-10-30T17:30:00"),
        endTime: new Date("2025-10-30T21:00:00"),
        location: "Davidson Winter Garden",
        locationType: "On-campus",
        center: "Zell",
        recruitingFocus: "Entrepreneurship",
        program: "All Programs",
        eventType: "Competition",
        tags: ["Entrepreneurship", "Venture Capital", "Networking"],
        registrationUrl: "https://zli.umich.edu/events/pitch-competition",
      },
      {
        title: "Consulting Club Case Workshop: Strategy Cases",
        description: "Practice strategy cases with current consultants from McKinsey, BCG, and Bain. Small group breakout sessions followed by feedback and Q&A.",
        startTime: new Date("2025-10-29T19:00:00"),
        endTime: new Date("2025-10-29T21:00:00"),
        location: "R2420",
        locationType: "On-campus",
        center: null,
        recruitingFocus: "Consulting",
        program: "BBA",
        eventType: "Club Event",
        tags: ["Consulting", "Case Prep", "MBB"],
        registrationUrl: "https://maize.umich.edu/organization/consulting-club",
      },
      {
        title: "iMpact Speaker Series: Social Innovation in Healthcare",
        description: "Dr. Sarah Chen, founder of HealthBridge, discusses building sustainable healthcare solutions for underserved communities. Part of the iMpact Center's Social Innovation Series.",
        startTime: new Date("2025-11-01T12:00:00"),
        endTime: new Date("2025-11-01T13:30:00"),
        location: "Online (Zoom)",
        locationType: "Online",
        center: "iMpact",
        recruitingFocus: null,
        program: "All Programs",
        eventType: "Speaker Event",
        tags: ["Social Impact", "Healthcare", "Innovation"],
        registrationUrl: "https://impact.umich.edu/events/speaker-series",
      },
      {
        title: "Investment Banking Networking Night",
        description: "Connect with Ross alumni working in investment banking at top bulge bracket firms. Casual networking followed by a panel discussion on recruiting timelines and interview prep.",
        startTime: new Date("2025-10-31T18:00:00"),
        endTime: new Date("2025-10-31T20:30:00"),
        location: "Seigle Hall Atrium",
        locationType: "On-campus",
        center: "Career Development",
        recruitingFocus: "Finance",
        program: "BBA",
        eventType: "Networking",
        tags: ["Finance", "Investment Banking", "Alumni"],
        registrationUrl: "https://rossrecruit.umich.edu/events/ib-networking",
      },
      {
        title: "Women in Leadership Conference 2025",
        description: "Michigan Business Women presents the annual WiLC conference featuring keynote speakers, breakout sessions, and networking opportunities focused on developing leadership skills.",
        startTime: new Date("2025-11-05T08:00:00"),
        endTime: new Date("2025-11-05T16:30:00"),
        location: "Ross School of Business",
        locationType: "On-campus",
        center: null,
        recruitingFocus: null,
        program: "MBA",
        eventType: "Conference",
        tags: ["Leadership", "Women", "Professional Development"],
        registrationUrl: "https://maize.umich.edu/organization/mbw",
      },
      {
        title: "Tech Trek: Silicon Valley Company Visits",
        description: "Join the Tech Club for a 3-day trek to Silicon Valley visiting Google, Meta, Apple, and meeting with Ross alumni at leading tech companies. Applications due Nov 1.",
        startTime: new Date("2025-11-15T08:00:00"),
        endTime: new Date("2025-11-17T18:00:00"),
        location: "Silicon Valley, CA",
        locationType: "Off-campus",
        center: null,
        recruitingFocus: "Tech",
        program: "MBA",
        eventType: "Trek",
        tags: ["Tech", "Silicon Valley", "Company Visits"],
        registrationUrl: "https://maize.umich.edu/organization/tech-club",
      },
      {
        title: "Private Equity Case Competition",
        description: "Team-based case competition sponsored by leading PE firms. Work on a real buyout case and present to industry professionals for prizes and recruiting opportunities.",
        startTime: new Date("2025-11-08T09:00:00"),
        endTime: new Date("2025-11-08T17:00:00"),
        location: "Blau Auditorium",
        locationType: "On-campus",
        center: null,
        recruitingFocus: "Finance",
        program: "MBA",
        eventType: "Competition",
        tags: ["Private Equity", "Finance", "Case Competition"],
        registrationUrl: "https://rossrecruit.umich.edu/events/pe-case-competition",
      },
      {
        title: "Sustainable Business Practices Panel",
        description: "Erb Institute presents a panel of sustainability leaders from Patagonia, Tesla, and Unilever discussing how to integrate environmental responsibility into business strategy.",
        startTime: new Date("2025-11-03T16:00:00"),
        endTime: new Date("2025-11-03T18:00:00"),
        location: "Tauber Colloquium",
        locationType: "On-campus",
        center: "Erb Institute",
        recruitingFocus: null,
        program: "All Programs",
        eventType: "Speaker Event",
        tags: ["Sustainability", "ESG", "Panel"],
        registrationUrl: "https://erb.umich.edu/events/sustainable-business-panel",
      },
      {
        title: "BBA Council Fall Social",
        description: "Join your fellow BBA students for food, games, and fun at the Fall Social. Great opportunity to meet students across all sections and relax before midterms.",
        startTime: new Date("2025-10-27T19:00:00"),
        endTime: new Date("2025-10-27T22:00:00"),
        location: "Michigan League",
        locationType: "On-campus",
        center: null,
        recruitingFocus: null,
        program: "BBA",
        eventType: "Social",
        tags: ["BBA Council", "Social", "Networking"],
        registrationUrl: "https://maize.umich.edu/organization/bba-council",
      },
      {
        title: "Fintech Innovation Workshop",
        description: "Learn about the latest trends in financial technology including blockchain, digital payments, and embedded finance. Hands-on workshop with industry practitioners.",
        startTime: new Date("2025-11-06T14:00:00"),
        endTime: new Date("2025-11-06T17:00:00"),
        location: "R2310",
        locationType: "On-campus",
        center: null,
        recruitingFocus: "Tech",
        program: "MBA",
        eventType: "Workshop",
        tags: ["Fintech", "Technology", "Finance"],
        registrationUrl: "https://rossrecruit.umich.edu/events/fintech-workshop",
      },
      {
        title: "Consulting Behavioral Interview Prep",
        description: "Practice your consulting behavioral interviews with experienced coaches. Get feedback on storytelling, leadership examples, and handling tough questions.",
        startTime: new Date("2025-11-04T18:30:00"),
        endTime: new Date("2025-11-04T20:30:00"),
        location: "Online (Zoom)",
        locationType: "Online",
        center: "Career Development",
        recruitingFocus: "Consulting",
        program: "All Programs",
        eventType: "Career Workshop",
        tags: ["Consulting", "Interview Prep", "Behavioral"],
        registrationUrl: "https://impact.umich.edu/events/behavioral-interview-prep",
      },
    ];

    sampleEvents.forEach((insertEvent) => {
      const id = randomUUID();
      const event: Event = {
        ...insertEvent,
        id,
        endTime: insertEvent.endTime ?? null,
        center: insertEvent.center ?? null,
        recruitingFocus: insertEvent.recruitingFocus ?? null,
        program: insertEvent.program ?? null,
        tags: insertEvent.tags ?? null,
        imageUrl: insertEvent.imageUrl ?? null,
        registrationUrl: insertEvent.registrationUrl ?? null,
      };
      this.events.set(id, event);
    });
  }

  private seedUserProfiles() {
    const sampleProfiles: InsertUserProfile[] = [
      {
        userId: "user1",
        fullName: "Sarah Chen",
        email: "schen@umich.edu",
        program: "BBA",
        graduationYear: "2026",
        careerInterests: ["Tech", "Product Management"],
        rossCenter: "Career Development",
        bio: "BBA '26 interested in product management at tech companies. Previously interned at Microsoft.",
      },
      {
        userId: "user2",
        fullName: "Michael Rodriguez",
        email: "mrodrig@umich.edu",
        program: "MBA",
        graduationYear: "2025",
        careerInterests: ["Consulting", "Strategy"],
        rossCenter: null,
        bio: "MBA '25 with 5 years of consulting experience at Deloitte. Happy to help with case prep!",
      },
      {
        userId: "user3",
        fullName: "Emily Thompson",
        email: "ethomps@umich.edu",
        program: "BBA",
        graduationYear: "2027",
        careerInterests: ["Finance", "Investment Banking"],
        rossCenter: "Career Development",
        bio: "BBA '27 pursuing investment banking. Looking to connect with finance-focused students.",
      },
      {
        userId: "user4",
        fullName: "David Park",
        email: "dpark@umich.edu",
        program: "MBA",
        graduationYear: "2025",
        careerInterests: ["Entrepreneurship", "Venture Capital"],
        rossCenter: "Zell",
        bio: "MBA '25 and Zell Lurie Fellow. Founded 2 startups before Ross. Love talking about startups!",
      },
      {
        userId: "user5",
        fullName: "Jessica Williams",
        email: "jwilli@umich.edu",
        program: "BBA",
        graduationYear: "2026",
        careerInterests: ["Consulting", "Healthcare"],
        rossCenter: null,
        bio: "BBA '26 interested in healthcare consulting. Member of Consulting Club.",
      },
      {
        userId: "user6",
        fullName: "Ryan Martinez",
        email: "rmartin@umich.edu",
        program: "MBA",
        graduationYear: "2026",
        careerInterests: ["Tech", "Fintech"],
        rossCenter: "Career Development",
        bio: "MBA '26 transitioning from finance to tech. Passionate about fintech innovation.",
      },
      {
        userId: "user7",
        fullName: "Aisha Patel",
        email: "apatel@umich.edu",
        program: "BBA",
        graduationYear: "2027",
        careerInterests: ["Social Impact", "Sustainability"],
        rossCenter: "iMpact",
        bio: "BBA '27 passionate about social entrepreneurship and sustainable business practices.",
      },
      {
        userId: "user8",
        fullName: "James Lee",
        email: "jlee@umich.edu",
        program: "MBA",
        graduationYear: "2025",
        careerInterests: ["Private Equity", "Finance"],
        rossCenter: null,
        bio: "MBA '25 with PE background. Recruiting for PE/VC roles post-graduation.",
      },
    ];

    sampleProfiles.forEach((insertProfile) => {
      const id = randomUUID();
      const profile: UserProfile = {
        ...insertProfile,
        id,
        rossCenter: insertProfile.rossCenter ?? null,
        bio: insertProfile.bio ?? null,
        avatarUrl: insertProfile.avatarUrl ?? null,
      };
      this.userProfiles.set(id, profile);
    });
  }

  private seedMessages() {
    const sampleMessages: InsertMessage[] = [
      {
        senderId: "user2",
        recipientId: "user1",
        content: "Hey Sarah! I saw you're interested in product management. I'd be happy to share some insights from my consulting background on PM roles.",
        isRead: "true",
      },
      {
        senderId: "user1",
        recipientId: "user2",
        content: "That would be amazing, Michael! I'm particularly curious about how to transition from consulting to PM.",
        isRead: "true",
      },
      {
        senderId: "user2",
        recipientId: "user1",
        content: "Happy to help! The key is understanding how to translate strategic frameworks into product roadmaps. Want to grab coffee this week?",
        isRead: "false",
      },
      {
        senderId: "user4",
        recipientId: "user1",
        content: "Hi Sarah! I'm organizing a Zell entrepreneurship workshop next week. Would you be interested in joining?",
        isRead: "false",
      },
      {
        senderId: "user3",
        recipientId: "user8",
        content: "Hi James! I'm a BBA student interested in finance. Could I ask you some questions about the MBA recruiting process for PE?",
        isRead: "true",
      },
      {
        senderId: "user8",
        recipientId: "user3",
        content: "Of course! PE recruiting is super competitive but definitely doable. What specific questions do you have?",
        isRead: "true",
      },
      {
        senderId: "user3",
        recipientId: "user8",
        content: "I'm wondering how important banking experience is versus other finance internships. Also, when should I start networking?",
        isRead: "false",
      },
      {
        senderId: "user5",
        recipientId: "user2",
        content: "Hi Michael! I saw you have consulting experience. Would you be willing to do a mock case interview with me?",
        isRead: "true",
      },
      {
        senderId: "user2",
        recipientId: "user5",
        content: "Absolutely! I'd be happy to. How about we schedule something for next Tuesday?",
        isRead: "false",
      },
    ];

    sampleMessages.forEach((insertMessage) => {
      const id = randomUUID();
      const message: Message = {
        ...insertMessage,
        id,
        sentAt: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000),
        isRead: insertMessage.isRead ?? "false",
      };
      this.messages.set(id, message);
    });
  }

  private seedResources() {
    const sampleResources: InsertResource[] = [
      {
        uploaderId: "user2",
        title: "Complete Guide to Consulting Case Interviews",
        description: "Comprehensive PDF covering frameworks, practice cases, and tips from students who landed offers at MBB firms. Includes market sizing, profitability, and growth strategy cases.",
        category: "Consulting",
        filePath: "/objects/sample-consulting-guide.pdf",
        fileName: "consulting-case-guide.pdf",
        fileSize: "2500000",
        upvotes: "156",
        downloadCount: "342",
      },
      {
        uploaderId: "user8",
        title: "Investment Banking Interview Prep",
        description: "Technical questions, accounting concepts, and valuation methods commonly asked in IB interviews. Created by Ross students who received offers from top bulge bracket banks.",
        category: "Finance",
        filePath: "/objects/sample-ib-prep.pdf",
        fileName: "ib-interview-prep.pdf",
        fileSize: "1800000",
        upvotes: "98",
        downloadCount: "215",
      },
      {
        uploaderId: "user1",
        title: "Leetcode Patterns for PM Tech Interviews",
        description: "Common coding patterns and data structures for product management technical screens. Includes solutions and explanations for 50+ Leetcode problems.",
        category: "Tech",
        filePath: "/objects/sample-leetcode-guide.pdf",
        fileName: "pm-tech-interview-guide.pdf",
        fileSize: "3200000",
        upvotes: "72",
        downloadCount: "128",
      },
      {
        uploaderId: "user4",
        title: "Startup Pitch Deck Template",
        description: "YC-style pitch deck template with examples from successful Ross-founded startups. Includes slides for problem, solution, market size, business model, and team.",
        category: "Entrepreneurship",
        filePath: "/objects/sample-pitch-deck.pptx",
        fileName: "startup-pitch-template.pptx",
        fileSize: "5000000",
        upvotes: "45",
        downloadCount: "89",
      },
      {
        uploaderId: "user5",
        title: "ACC 300 Final Exam Study Guide",
        description: "Comprehensive study guide for ACC 300 covering all major topics: journal entries, financial statements, ratio analysis, and valuation. Created by A+ students.",
        category: "Classes",
        filePath: "/objects/sample-acc300-guide.pdf",
        fileName: "acc300-study-guide.pdf",
        fileSize: "1500000",
        upvotes: "134",
        downloadCount: "267",
      },
      {
        uploaderId: "user6",
        title: "Ross Club Application Templates",
        description: "Successful application essays and resumes for top Ross clubs including Consulting Club, Finance Club, and Product Management Club. Learn what works!",
        category: "Clubs",
        filePath: "/objects/sample-club-apps.pdf",
        fileName: "club-application-templates.pdf",
        fileSize: "1200000",
        upvotes: "89",
        downloadCount: "178",
      },
      {
        uploaderId: "user7",
        title: "Social Impact Consulting Resources",
        description: "Guide to breaking into social impact consulting with firms like Bridgespan and FSG. Includes case frameworks, networking tips, and sample cover letters.",
        category: "Recruitment",
        filePath: "/objects/sample-social-impact.pdf",
        fileName: "social-impact-consulting.pdf",
        fileSize: "2100000",
        upvotes: "56",
        downloadCount: "94",
      },
      {
        uploaderId: "user3",
        title: "FIN 300 Cheat Sheet",
        description: "One-page cheat sheet covering all FIN 300 formulas: NPV, IRR, WACC, CAPM, bond pricing, and option valuation. Perfect for exams and interviews.",
        category: "Classes",
        filePath: "/objects/sample-fin300-cheat.pdf",
        fileName: "fin300-cheat-sheet.pdf",
        fileSize: "500000",
        upvotes: "203",
        downloadCount: "421",
      },
    ];

    sampleResources.forEach((insertResource) => {
      const id = randomUUID();
      const resource: Resource = {
        ...insertResource,
        id,
        createdAt: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000),
        upvotes: insertResource.upvotes ?? "0",
        downloadCount: insertResource.downloadCount ?? "0",
      };
      this.resources.set(id, resource);
    });
  }
}

export const storage = new MemStorage();
