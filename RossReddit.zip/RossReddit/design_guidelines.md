# Design Guidelines: Ross Reddit - Michigan Ross Edition

## Design Approach

**Selected Approach:** Reference-based design inspired by Michigan Ross iMpact Web Portal, combining university brand standards with modern community platform patterns from Linear (typography clarity) and Notion (information architecture).

**Rationale:** Ross Reddit serves as the digital hub for Michigan Ross students, requiring a professional, trustworthy aesthetic that reflects institutional identity while maintaining the engagement patterns of modern social platforms. The large hero section establishes credibility and community belonging, while card-based navigation provides intuitive wayfinding.

**Key Design Principles:**
1. Michigan Ross brand integrity with modern execution
2. Generous white space for professionalism and clarity
3. Card-based information architecture for scannability
4. Hierarchical navigation supporting both discovery and utility
5. Desktop-first with mobile optimization

---

## Brand Identity

**Brand Colors:**
- Primary: Michigan Blue (#00274C) - Navigation bar, headers, primary CTAs
- Accent: Maize (#FFCB05) - Important buttons, notifications, active states, highlights
- Use white and light grays as dominant background colors for breathing room

---

## Typography System

**Font Families:**
- Primary: Inter (Google Fonts) - Professional, highly legible
- Secondary: Crimson Pro (Google Fonts) - Serif for hero headlines, editorial content

**Type Scale:**
- Hero Headline: text-5xl md:text-6xl, font-bold, tracking-tight (Crimson Pro)
- Hero Subheadline: text-xl md:text-2xl, font-normal, leading-relaxed
- Page Titles: text-3xl, font-bold
- Section Headers: text-2xl, font-semibold
- Card Titles: text-lg, font-semibold
- Body Text: text-base, leading-relaxed
- Meta Text: text-sm
- Labels: text-xs, font-medium, uppercase, tracking-wide

---

## Layout System

**Spacing Primitives:** Tailwind units 4, 6, 8, 12, 16, 20, 24
- Generous section padding: py-16 to py-24
- Card padding: p-6 to p-8
- Component gaps: gap-6 to gap-8
- Page margins: px-6 md:px-8 lg:px-12

**Grid System:**
- Hero section: Full-width with max-w-7xl inner container
- Main content: max-w-7xl with sidebar layout (2/3 content + 1/3 sidebar)
- Card grids: grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6
- Navigation sections: grid-cols-2 lg:grid-cols-4 for category cards

**Page Structure:**
- Sticky horizontal top navigation (h-20)
- Full-width hero section (min-h-96 md:min-h-[500px])
- Main content area with right sidebar (desktop)
- Generous vertical rhythm between sections

---

## Component Library

### Navigation

**Top Navigation Bar:**
- Sticky header, full-width with Michigan Blue background
- Height: h-20
- Inner container: max-w-7xl with horizontal flex layout
- Left: Ross Reddit logo (Michigan Block M + wordmark)
- Center: Main navigation links (Forum, Events, Resources, Mentorship, About)
- Right: Search icon, Notifications (bell with badge), Profile avatar
- White text with hover states
- Mobile: Hamburger menu, slide-in drawer navigation

**Navigation Categories (Below Hero):**
- Large rounded cards in 4-column grid (2-column on tablet, 1-column mobile)
- Card size: min-h-48, p-8
- Each card: Icon (w-12 h-12), Title (text-xl font-semibold), Description (text-sm), Arrow indicator
- Categories: Forum Discussions, Upcoming Events, Resource Library, Mentorship Network
- Cards have subtle shadow (shadow-md) with hover elevation (shadow-lg)

### Hero Section

**Structure:**
- Full-width container with Michigan Blue background
- Height: min-h-96 md:min-h-[500px]
- Inner content: max-w-7xl centered
- Layout: 60/40 split (content/image on desktop)
- Content: Headline + Subheadline + 2 CTAs (primary Maize button + secondary outlined)
- Background: Michigan Ross campus image with 40% opacity overlay
- Text: White on semi-transparent dark background panels for readability
- CTAs: Buttons with backdrop-blur-md background for depth

**Content:**
- Headline: "Connect. Learn. Succeed." or "Your Ross Community Starts Here"
- Subheadline: Brief value proposition (2 lines max)
- Primary CTA: "Join the Conversation" (Maize background)
- Secondary CTA: "Explore Events" (white border, transparent background with blur)

### Cards & Content Containers

**Forum Post Card:**
- Rounded: rounded-xl
- Background: white with subtle border
- Padding: p-6
- Shadow: shadow-sm hover:shadow-md transition
- Structure: Author header (avatar + name + badge + timestamp) → Content → Tags → Footer (upvote count, comment count, bookmark)
- Spacing: space-y-4 between sections

**Large Navigation Card:**
- Rounded: rounded-2xl
- Padding: p-8
- Background: white
- Shadow: shadow-md
- Icon container with accent background (w-16 h-16, rounded-full)
- Title + 2-line description
- Hover: Lift effect with shadow-xl

**Event Card (Grid View):**
- Rounded: rounded-xl
- Aspect ratio maintained with image header
- Structure: Event image → Date badge (absolute positioned) → Title → Location + Time → RSVP count → Action button
- Compact footer with Maize accent for featured events

**Mentor Profile Card:**
- Centered layout with generous padding (p-8)
- Large avatar (w-32 h-32, rounded-full, border-4 with white)
- Name + Class Year + Major
- Expertise tags (pill style, 3-4 tags max)
- Bio preview (3 lines, truncated)
- "Request Match" CTA button (full-width)
- Card shadow: shadow-lg

### Sidebar (Right Rail - Desktop)

**Quick Actions Panel:**
- Sticky positioning (top-24 to account for nav)
- Width: w-80
- Background: white, rounded-xl, shadow-md
- Padding: p-6
- Sections (with dividers):
  1. **Post Question** - Primary CTA button (full-width, Maize)
  2. **Upcoming Events** - 3 mini event cards with date badges
  3. **Active Matches** - Avatar stack with count
  4. **Trending Tags** - 6-8 clickable tag pills
- Each section: mb-6 spacing

**Sticky Filters Panel (Forum Pages):**
- Filter by category chips
- Sort dropdown
- Time range selector
- "Reset Filters" link

### Forms & Inputs

**Search Bar (Top Nav):**
- Width: w-64 expandable to w-96 on focus
- Height: h-12
- Rounded: rounded-full
- White background with opacity
- Icon prefix, placeholder text

**Text Inputs:**
- Height: h-14
- Rounded: rounded-lg
- Border: 2px solid with focus ring in Maize
- Padding: px-4
- Background: white

**Post Creation Form:**
- Multi-step wizard for desktop (single scrolling form on mobile)
- Rich text editor with toolbar
- Tag selector with autocomplete
- Anonymous posting toggle switch
- Preview panel (desktop, right side)
- "Post Question" primary CTA (Maize background)

### Buttons

**Primary (Maize):**
- Height: h-12, px-8
- Rounded: rounded-lg
- Text: text-base font-semibold
- Examples: "Post Question", "RSVP Now", "Send Message"

**Secondary (Michigan Blue):**
- Height: h-12, px-8
- Outlined variant with border-2
- Examples: "Learn More", "View All Events"

**Icon Buttons:**
- Size: w-12 h-12
- Rounded: rounded-lg
- Subtle hover background

### Data Displays

**Feed Layout:**
- Max-width: max-w-4xl for readability
- Cards with mb-6 spacing
- Filter chips row at top (sticky)
- Infinite scroll with loading states

**Event Calendar:**
- Full-width calendar grid on desktop
- List view on mobile with date headers
- Color-coded event categories
- Today highlighted with Maize border

**Statistics Dashboard:**
- 4-column grid (grid-cols-2 lg:grid-cols-4)
- Large number display (text-4xl font-bold)
- Label below (text-sm uppercase tracking-wide)
- Icon in corner
- Cards: p-6, rounded-xl, shadow-md

### Modals

**Dialog Structure:**
- Max-width: max-w-3xl
- Backdrop: Semi-transparent Michigan Blue with blur
- Content: white, rounded-2xl, shadow-2xl
- Header: p-6 with close button
- Body: p-6
- Footer: p-6 with action buttons (right-aligned)

---

## Images

**Hero Section:**
- Large hero image: Michigan Ross building exterior, student collaboration in modern spaces, or campus aerial view
- Treatment: 40% opacity overlay with Michigan Blue tint
- Positioning: Cover background, centered
- Alternative: Split layout with image on right (40% width on desktop)

**Event Cards:**
- Event banner images (aspect-ratio-video)
- Placeholder: Michigan Ross campus imagery or club logos
- Fallback: Solid Michigan Blue background with Maize icon

**Profile Avatars:**
- User photos throughout (rounded-full)
- Sizes: w-10 h-10 (lists), w-16 h-16 (cards), w-32 h-32 (profiles), w-40 h-40 (profile page)
- Fallback: Initials on Maize background for users without photos

**Resource Thumbnails:**
- Document previews where applicable
- File type icons: PDF, DOCX, XLSX with Michigan Blue backgrounds

**Navigation Category Cards:**
- Custom icons (w-12 h-12) in light Maize circular backgrounds
- Categories: Forum (chat bubbles), Events (calendar), Resources (books), Mentorship (handshake)

---

## Accessibility & Responsiveness

- Minimum touch targets: 44×44px
- Focus rings: Maize (ring-2 ring-offset-2)
- Keyboard navigation with visible focus states
- ARIA labels for all icon buttons
- Skip to main content link
- Color contrast meeting WCAG AA standards

**Responsive Breakpoints:**
- Mobile (<768px): Stacked layout, bottom nav bar, full-width cards
- Tablet (768-1024px): 2-column grids, collapsible sidebar
- Desktop (>1024px): Full layout with persistent sidebar, multi-column grids

**Mobile Adaptations:**
- Hero: Reduced height (min-h-64), centered content, stacked CTAs
- Navigation cards: Single column, reduced padding
- Sidebar: Hidden, accessible via drawer or bottom sheet
- Forms: Full-screen modals
- Event calendar: List view only